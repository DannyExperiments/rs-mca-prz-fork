#!/usr/bin/env bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1
ROOT=$(cd "$(dirname "$0")/.." && pwd)
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

CXX=${CXX:-g++}

python3 "$ROOT/src/field_reference.py" > "$TMP/field.json"
grep -q 'FIELD_REFERENCE_SELFTEST_PASS' "$TMP/field.json"
diff -u "$ROOT/examples/field_reference_output.json" "$TMP/field.json"

"$CXX" -O3 -std=c++20 "$ROOT/src/cycle87_build_u_slot_logs.cpp" \
  -o "$TMP/cycle87_build_u_slot_logs"
"$TMP/cycle87_build_u_slot_logs" > "$TMP/u-slot.json"
python3 -m json.tool "$TMP/u-slot.json" >/dev/null
diff -u "$ROOT/examples/cycle87_u_slot_smooth_logs.json" "$TMP/u-slot.json"

# The two independent exact Python verifiers are CPU-bound and share no state.
# Running them concurrently reduces wall-clock time without changing outputs.
PYTHONPATH="$ROOT/src" python3 "$ROOT/src/verify_u_slot_logs.py" \
  "$TMP/u-slot.json" > "$TMP/u-slot-verify.json" &
PID_SLOT=$!
PYTHONPATH="$ROOT/src" python3 "$ROOT/src/verify_geometry_464.py" \
  > "$TMP/geometry464.json" &
PID_GEOM=$!
wait "$PID_SLOT"
wait "$PID_GEOM"

grep -q 'U_SLOT_LOGS_VERIFY_PASS' "$TMP/u-slot-verify.json"
diff -u "$ROOT/examples/u_slot_logs_verification_output.json" "$TMP/u-slot-verify.json"
grep -q 'GEOMETRY_464_VERIFY_PASS' "$TMP/geometry464.json"
diff -u "$ROOT/examples/cycle87_geometry_464_certificate.json" "$TMP/geometry464.json"

PYTHONPATH="$ROOT/src" python3 "$ROOT/src/verify_result_envelope.py" \
  "$ROOT/examples/REFINE_REQUIRED.example.json" > "$TMP/envelope.json"
grep -q 'STATIC_RESULT_ENVELOPE_PASS' "$TMP/envelope.json"
diff -u "$ROOT/examples/static_envelope_output.json" "$TMP/envelope.json"

python3 -m json.tool "$ROOT/inputs/INPUTS.lock.json" >/dev/null
python3 -m json.tool "$ROOT/schemas/cycle87_shard.schema.json" >/dev/null
python3 -m json.tool "$ROOT/schemas/cycle87_geometry_464.schema.json" >/dev/null
python3 -m json.tool "$ROOT/schemas/cycle87_result.schema.json" >/dev/null

if command -v sha256sum >/dev/null 2>&1; then
  (cd "$ROOT" && sha256sum -c SHA256SUMS.txt)
fi

echo FIELD_REFERENCE_SELFTEST_PASS
echo U_SLOT_LOGS_VERIFY_PASS
echo GEOMETRY_464_VERIFY_PASS
echo STATIC_RESULT_ENVELOPE_PASS
echo BUNDLE_SELFTEST_PASS
