# Cycle87 certificate-engineer bundle

This bundle is a **replay specification plus an independently verified setup
artifact** for the active wall

```text
V-CYCLE86-U-PROJECTIVE-MMAX8-CENSUS.
```

It does not claim that the 26,373,783,552-record folded census has already
passed.  It makes two exact reductions, materializes the complete 336-row slot
table, and materializes the preferred 464-point one-GRS/one-line construction.

## Banked reductions

For

```text
F0 = F_17[X]/(X^16+X^8+3),
beta = X+2,
L = F0[U]/(U^3-beta),
y = U,
```

the projective quotient has order

```text
|L^x/F0^x| = S*r,
S = 48,661,191,882,642,625,923
  = 3*7*13*73*307*1321*72337*83233,
r = 48,661,191,868,691,111,041 (prime).
```

The smooth projection satisfies

```text
mu_proj(U) <= mu_s(U).
```

The Cycle79 complement involution then halves the admissible scan exactly.  If
`n(q)` counts canonical tuple orbits at folded key `q`, then

```text
mu_s(U) <= 8
iff
n(q) <= 8 for q>0, and n(0) <= 4.
```

Thus the primary run scans **26,373,783,552**, not 52,747,567,104, compatible
pairs.  A smooth bucket above its threshold triggers exact 48-byte projective
refinement; it is never itself labeled FAIL.

## Materialized setup

`src/cycle87_build_u_slot_logs.cpp` is an executable C++20 producer.  It
reconstructs all 336 extension-field slot factors, proves the selected smooth
generator has order `S`, computes every smooth discrete logarithm by exact
Pohlig--Hellman/CRT, verifies the exact complement identities, and checks both
the full and folded color-shell counts.

Its committed output is

```text
examples/cycle87_u_slot_smooth_logs.json
sha256 = bc9e8ef7dfe4fc8cca89e82b3ec150a12ec0cfbe1be3e641b62b05e623ba9987
```

with

```text
tau_kappa = 13,943,676,897,899,455,034
tau_delta =  6,971,838,448,949,727,517.
```

`src/verify_u_slot_logs.py` independently reconstructs every factor and checks
all 336 exponent identities by field exponentiation.  This local setup is not
a substitute for hashing the authoritative Cycle84 public-replay source; that
source dependency remains pinned in `inputs/INPUTS.lock.json`.

## Materialized 464 geometry

`src/verify_geometry_464.py` exactly verifies the shortening, all 336 option-
block six-jets, the ordered 464-point domain, the one `[464,232]` GRS matrix,
the single affine syndrome line, transversality, and a complete 226-support
barycentric syndrome identity.  Its committed certificate records

```text
domain_sha256        = 6aa1eb735afbaaf36eefb3ac080123fb49c9e32d0dd861cd635c54ad42991f76
code_matrix_sha256   = 5ee34d5a29e09180fa82d09ea07abec9006cdead736ce1c9506b76a887f7bcce
syndrome_line_sha256 = 6b49252971502a27e49a673b20f3ed2457557432232eb8116f56da602e272e2a
```

The 560 fallback is therefore not needed for this explicit model.

## Included

* `SPEC.md` — exact theorem, folded census, exact refinement, 464 GRS geometry,
  PASS/FAIL semantics, and reviewer workflow.
* `inputs/INPUTS.lock.json` — Cycle84/Cycle85/context hashes and generated setup
  hashes.
* `schemas/` — result, shard, and 464-geometry JSON schemas.
* `src/field_reference.py` — independent field/group/threshold self-test.
* `src/cycle87_build_u_slot_logs.cpp` — executable 336-row setup producer.
* `src/verify_u_slot_logs.py` — independent Python verifier for that table.
* `src/cycle87_tau_folded_scan.pseudocode` — implementation-complete census,
  sharding, normalization, exact refinement, and verifier pseudocode.
* `src/verify_geometry_464.py` — executable materializer/verifier for the 464
  GRS/affine-line package.
* `src/verify_result_envelope.py` — static result-envelope checker; it does not
  replace full shard regeneration.

## Local replay

```bash
./scripts/reproduce.sh
```

Expected terminal markers:

```text
FIELD_REFERENCE_SELFTEST_PASS
U_SLOT_LOGS_VERIFY_PASS
GEOMETRY_464_VERIFY_PASS
STATIC_RESULT_ENVELOPE_PASS
BUNDLE_SELFTEST_PASS
```

## Missing theorem execution

A theorem result still requires:

1. the pinned public Cycle84 model bytes;
2. all folded census shards, totaling exactly `26,373,783,552` records;
3. exact refinement of every saturated folded key;
4. an independent full-shard replay and acceptance certificate.

## Decision discipline

* `PASS` proves `mu_proj(U)<=8`, verifies the 464 construction, and clears the
  official `2^-128` finite target.
* `FAIL_PROJECTIVE_MMAX_GE_9` contains nine exact equal projective keys.
* `REFINE_REQUIRED` means only that a folded smooth bucket crossed its coarse
  threshold.
* `ERROR` is operational or dependency failure.

A FAIL for `U` does not disprove generic separator existence.  A PASS is an
official two-copy finite MCA counterpacket only after public replay; it is not
the full proximity-prize theorem.
