#!/usr/bin/env python3
"""Materialize and verify the Cycle87 shortened 464 GRS construction.

The script uses only the standard-library arithmetic from field_reference.py.
It checks universal shortening, all 336 slot-block six-jets, the 464 domain,
the one-GRS basis, transversality, and one full 226-support syndrome identity.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from field_reference import (
    P, Q0, QLINE, ETA, BETA, ZERO0, ONE0, ZEROL, ONEL, U,
    F0, L, encode_l48, f0_add, f0_sub, f0_mul, f0_pow,
    l_add, l_mul, l_pow,
)

E_SETS = {
    1: (0,1,2,3,5,11,12,13),
    2: (0,1,2,3,4,8,9,14),
    3: (0,1,2,4,5,7,11,14),
}
BASE_COLOR = {1:15,2:9,3:12}
TRUNC=6


def f0_neg(x:F0)->F0: return f0_sub(ZERO0,x)
def lemb(x:F0)->L: return (x,ZERO0,ZERO0)
def l_sub(x:L,y:L)->L: return tuple(f0_sub(x[j],y[j]) for j in range(3))  # type: ignore[return-value]
def l_neg(x:L)->L: return l_sub(ZEROL,x)
def l_eq_zero(x:L)->bool: return x==ZEROL

def color(k:int)->int:
    i,a=divmod(k,16);i+=1
    return (BASE_COLOR[i]+8*(a&1))%16

def poly_mul_trunc(a:list[L],b:list[L],n:int=TRUNC)->list[L]:
    c=[ZEROL for _ in range(n)]
    for i,x in enumerate(a):
        if i>=n: break
        for j,y in enumerate(b):
            if i+j>=n: break
            c[i+j]=l_add(c[i+j],l_mul(x,y))
    return c

def one_minus_xt(x:L)->list[L]:
    return [ONEL,l_neg(x)]+[ZEROL]*(TRUNC-2)

def poly_pow_trunc(a:list[L],e:int)->list[L]:
    z=[ONEL]+[ZEROL]*(TRUNC-1)
    while e:
        if e&1:z=poly_mul_trunc(z,a)
        a=poly_mul_trunc(a,a);e//=2
    return z

def poly_inv_unit(a:list[L])->list[L]:
    assert a[0]==ONEL
    h=[ZEROL for _ in range(TRUNC)];h[0]=ONEL
    for n in range(1,TRUNC):
        s=ZEROL
        for i in range(1,n+1): s=l_add(s,l_mul(a[i],h[n-i]))
        h[n]=l_neg(s)
    assert poly_mul_trunc(a,h)==[ONEL]+[ZEROL]*(TRUNC-1)
    return h

def block_roots(t:int,k:int)->list[F0]:
    i,a=divmod(k,16);i+=1
    out=[]
    for e in E_SETS[i]:
        b=(a+e)&15
        r=f0_pow(ETA,t+8*b)
        out.extend((r,f0_neg(r)))
    assert len(out)==16 and len(set(out))==16
    return out

def support(options:list[int])->list[F0]:
    out=[ONE0]
    for t,k in enumerate(options,1): out.extend(block_roots(t,k))
    assert len(out)==113 and len(set(out))==113
    return out

def find_first_color4()->list[int]:
    memo={}
    def go(t:int,res:int):
        if t==7:return [] if res%16==4 else None
        key=(t,res); 
        if key in memo:return memo[key]
        for k in range(48):
            z=go(t+1,(res+color(k))%16)
            if z is not None:
                memo[key]=[k]+z;return memo[key]
        memo[key]=None;return None
    ans=go(0,0); assert ans is not None
    return ans

def batch_inverse(xs:list[L])->list[L]:
    pref=[ONEL]
    for x in xs:
        assert x!=ZEROL
        pref.append(l_mul(pref[-1],x))
    inv=l_pow(pref[-1],QLINE-2)
    out=[ZEROL]*len(xs)
    for i in range(len(xs)-1,-1,-1):
        out[i]=l_mul(pref[i],inv)
        inv=l_mul(inv,xs[i])
    for x,y in zip(xs,out): assert l_mul(x,y)==ONEL
    return out

def hash_elements(tag:bytes,xs:list[L])->str:
    h=hashlib.sha256();h.update(tag+b'\0')
    for x in xs:h.update(encode_l48(x))
    return h.hexdigest()

def main()->None:
    assert f0_pow(ETA,256)==ONE0 and f0_pow(ETA,128)==f0_neg(ONE0)
    assert f0_pow(ETA,17**8)!=ETA  # degree 16 over F17

    # Every 16-root option block has jet 1 mod t^6.
    unit=[ONEL]+[ZEROL]*(TRUNC-1)
    for t in range(1,8):
        for k in range(48):
            jet=unit
            for r in block_roots(t,k): jet=poly_mul_trunc(jet,one_minus_xt(lemb(r)))
            assert jet==unit
    one_copy_jet=one_minus_xt(ONEL)

    excluded={8*b for b in range(1,25)}
    exponents=[e for e in range(256) if e not in excluded]
    assert len(exponents)==232 and 1 in exponents and 0 in exponents
    dminus=[lemb(f0_pow(ETA,e)) for e in exponents]
    betaL=lemb(BETA)
    c=l_sub(betaL,U)
    translated=[l_add(c,d) for d in dminus]
    domain=dminus+translated
    assert len(domain)==464 and len(set(domain))==464
    assert betaL not in domain

    # Universal shortening: root 1 is retained; all slot roots have exponent
    # t mod 8 with t=1,...,7, hence avoid the removed exponent class 0 mod 8.
    for t in range(1,8):
        for k in range(48):
            for r in block_roots(t,k):
                assert lemb(r) in dminus
    assert ONEL in dminus

    # Dminus contains eta and generates F0; c and any c+d recover U.
    assert lemb(ETA) in dminus
    assert l_sub(translated[0],dminus[0])==c
    assert l_sub(betaL,c)==U

    # Fixed combined jet and inverse coefficients.
    omct=one_minus_xt(c)
    cplus1=l_add(c,ONEL)
    combined_jet=poly_mul_trunc(one_copy_jet,
        poly_mul_trunc(poly_pow_trunc(omct,112),one_minus_xt(cplus1)))
    hcoeff=poly_inv_unit(combined_jet)
    syndrome_base=[ZEROL]*225+hcoeff+[ZEROL]
    direction=[ZEROL]*231+[ONEL]
    assert len(syndrome_base)==232 and len(direction)==232

    # Hash the exact ordered domain and actual parity-check matrix H_x.
    domain_hash=hash_elements(b'rs-mca.cycle87.domain464.v1',domain)
    beta_minus=[l_sub(betaL,x) for x in domain]
    beta_minus_inv=batch_inverse(beta_minus)
    hm=hashlib.sha256();hm.update(b'rs-mca.cycle87.H464x232.column-major.v1\0')
    for x,inv in zip(domain,beta_minus_inv):
        power=ONEL
        for _m in range(231):
            hm.update(encode_l48(power)); power=l_mul(power,x)
        hm.update(encode_l48(inv))
    matrix_hash=hm.hexdigest()
    line_hash=hash_elements(b'rs-mca.cycle87.affine-line.base-direction.v1',syndrome_base+direction)

    # Basis/GRS proof checks: beta-x is nonzero; the 232 polynomials
    # (beta-Y)Y^m, 0<=m<=230, and 1 have distinct leading-echelon degrees and
    # form a basis of L[Y]_{<=231}.  Distinct domain points make evaluation
    # injective in degree <=231.  Column scales beta-x are nonzero.
    assert all(z!=ZEROL for z in beta_minus)

    # One full admissible support verifies the complete barycentric syndrome
    # identities and all signs/indices used by the generic proof.
    opts=find_first_color4(); assert sum(map(color,opts))%16==4
    T1=support(opts); T2=support(opts)
    Spts=[lemb(x) for x in T1]+[l_add(c,lemb(x)) for x in T2]
    assert len(Spts)==226 and len(set(Spts))==226
    sample_jet=unit
    for x in Spts: sample_jet=poly_mul_trunc(sample_jet,one_minus_xt(x))
    assert sample_jet==combined_jet

    deriv=[]
    for i,x in enumerate(Spts):
        z=ONEL
        for j,y in enumerate(Spts):
            if i!=j:z=l_mul(z,l_sub(x,y))
        deriv.append(z)
    weights=batch_inverse(deriv)
    sums=[ZEROL]*231
    for a,x in zip(weights,Spts):
        power=ONEL
        for m in range(231):
            sums[m]=l_add(sums[m],l_mul(a,power))
            power=l_mul(power,x)
    assert sums==syndrome_base[:231]
    denom=[l_sub(betaL,x) for x in Spts]
    invden=batch_inverse(denom)
    last=ZEROL
    p_at_beta=ONEL
    for a,d,di in zip(weights,denom,invden):
        last=l_add(last,l_mul(a,di)); p_at_beta=l_mul(p_at_beta,d)
    assert last==l_pow(p_at_beta,QLINE-2)
    assert last!=ZEROL

    # Product factorization P_S(beta)=P_T1(beta)P_T2(U).
    rho=ONEL
    for x in T1:rho=l_mul(rho,l_sub(betaL,lemb(x)))
    ptu=ONEL
    for x in T2:ptu=l_mul(ptu,l_sub(U,lemb(x)))
    assert p_at_beta==l_mul(rho,ptu)

    sample_hash=hash_elements(b'rs-mca.cycle87.sample-support226.v1',Spts)
    out={
      'schema':'rs-mca.cycle87.geometry464.v1',
      'status':'GEOMETRY_464_VERIFY_PASS',
      'parameters':{'n':464,'k':232,'sigma':6,'j':226},
      'universal_avoidance':True,
      'domain_distinct':True,
      'beta_avoided':True,
      'domain_generates_L':True,
      'common_jet':True,
      'one_grs_code':True,
      'one_affine_syndrome_line':True,
      'transverse':True,
      'domain_sha256':domain_hash,
      'code_matrix_sha256':matrix_hash,
      'syndrome_line_sha256':line_hash,
      'common_jet_coeffs_48_hex':[encode_l48(x).hex() for x in combined_jet],
      'inverse_jet_coeffs_48_hex':[encode_l48(x).hex() for x in hcoeff],
      'sample_tuple_options':opts,
      'sample_support_sha256':sample_hash,
      'sample_syndrome_verified':True,
      'domain_entries':464,
      'code_matrix_entries':464*232,
      'fallback_560_needed':False,
    }
    print(json.dumps(out,sort_keys=True,indent=2))

if __name__=='__main__': main()
