#!/usr/bin/env python3
"""Verify the Cycle87 result envelope and all static arithmetic.

This verifier deliberately does not certify the expensive absence result.
A theorem PASS additionally requires independent regeneration of every shard
and the 464 geometry, as specified in SPEC.md.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from field_reference import Q0, QLINE, QPROJ, S, R, PACKETS, OCCUPIED, TARGET, S_FACTORS

FOLDED = PACKETS // 2
H = (S + 1) // 2
TAU_KAPPA = 13_943_676_897_899_455_034
TAU_DELTA = 6_971_838_448_949_727_517
CANONICAL_FIRST = list(range(16)) + list(range(32, 40))
DOMAIN464_SHA = '6aa1eb735afbaaf36eefb3ac080123fb49c9e32d0dd861cd635c54ad42991f76'
MATRIX464_SHA = '5ee34d5a29e09180fa82d09ea07abec9006cdead736ce1c9506b76a887f7bcce'
LINE464_SHA = '6b49252971502a27e49a673b20f3ed2457557432232eb8116f56da602e272e2a'


def require(cond: bool, message: str) -> None:
    if not cond:
        raise ValueError(message)


def is_int_le(x: object, bound: int) -> bool:
    return isinstance(x, int) and not isinstance(x, bool) and 0 <= x <= bound


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("result", type=Path)
    args = ap.parse_args()
    cert = json.loads(args.result.read_text(encoding="utf-8"))

    require(cert.get("schema") == "rs-mca.cycle87.separator-result.v3", "bad schema")
    require(cert.get("target") == "V-CYCLE86-U-PROJECTIVE-MMAX8-CENSUS", "bad target")
    decision = cert.get("decision")
    require(decision in {"PASS", "FAIL_PROJECTIVE_MMAX_GE_9", "REFINE_REQUIRED", "ERROR"}, "bad decision")

    field = cert["field"]
    require(field["q0"] == str(Q0), "q0 mismatch")
    require(field["q_line"] == str(QLINE), "q_line mismatch")
    require(field["projective_group_order"] == str(QPROJ), "projective order mismatch")
    require(field["smooth_order"] == str(S), "smooth order mismatch")
    require(field["hard_order"] == str(R), "hard order mismatch")
    require(field["smooth_factorization"] == list(S_FACTORS), "smooth factors mismatch")

    model = cert["model"]
    require(model["packet_count"] == str(PACKETS), "packet count mismatch")
    require(model["folded_packet_count"] == str(FOLDED), "folded packet count mismatch")
    require(model["occupied_rho_count"] == str(OCCUPIED), "occupied count mismatch")
    require(model["slot_factor_records"] == 336, "slot count mismatch")
    require(model["full_left_records"] == 110_592, "full left size mismatch")
    require(model["folded_left_records"] == 55_296, "folded left size mismatch")
    require(model["right_records"] == 5_308_416, "right size mismatch")

    smooth = cert["smooth_projection"]
    require(smooth["tau_kappa"] == str(TAU_KAPPA), "tau kappa mismatch")
    require(smooth["tau_delta"] == str(TAU_DELTA), "tau delta mismatch")
    require(smooth["folded_key_space_size"] == str(H), "folded key-space mismatch")
    require(smooth["canonical_first_options"] == CANONICAL_FIRST, "canonical first options mismatch")

    threshold = cert["threshold"]
    lower = PACKETS * OCCUPIED // 8
    require(threshold["T_line"] == str(TARGET), "T_line mismatch")
    require(threshold["numerator_lower_bound"] == str(lower), "numerator mismatch")
    require(threshold["margin"] == str(lower - TARGET), "margin mismatch")
    require(threshold["q_line"] == str(QLINE), "threshold q_line mismatch")

    census = cert["census"]
    require(census["enumeration_mode"] == "TAU_FOLDED", "wrong enumeration mode")
    construction = cert["construction_464"]
    require(construction["domain_sha256"] == DOMAIN464_SHA, "464 domain hash mismatch")
    require(construction["code_matrix_sha256"] == MATRIX464_SHA, "464 matrix hash mismatch")
    require(construction["syndrome_line_sha256"] == LINE464_SHA, "464 line hash mismatch")
    witness = cert["witness"]
    error = cert["error"]

    if decision != "ERROR":
        require(census["full_domain"] is True, "mathematical decision is not full-domain")
        require(census["enumerated_records"] == str(FOLDED), "folded record total mismatch")
        require(census["logical_packet_records"] == str(PACKETS), "logical record total mismatch")
        require(census["shards_complete"] == smooth["shard_count"], "incomplete shard set")

    if decision == "PASS":
        require(all(d["verified"] for d in cert["dependencies"]), "PASS has unverified dependency")
        require(construction["verified"] is True, "PASS lacks 464 geometry")
        require(threshold["clears_target"] is True, "PASS threshold flag false")
        require(witness is None and error is None, "PASS has witness/error")
        mode = cert["proof_mode"]
        if mode == "SMOOTH_DOMINATION":
            nq = census["nonzero_q_max"]
            n0 = census["zero_q_count"]
            require(is_int_le(nq, 8), "smooth PASS has nonzero q saturation")
            require(is_int_le(n0, 4), "smooth PASS has q=0 saturation")
            require(census["smooth_mu_upper"] == max(nq, 2 * n0), "wrong smooth upper bound")
            require(census["smooth_mu_upper"] <= 8, "smooth upper bound exceeds 8")
            require(census["exact_projective_max"] == "NOT_NEEDED", "unexpected exact status")
        else:
            require(mode == "SMOOTH_PLUS_EXACT_REFINEMENT", "bad PASS proof mode")
            require(census["exact_refinement_complete"] is True, "refined PASS is incomplete")
            require(is_int_le(census["exact_projective_max"], 8), "exact projective max exceeds 8")
    elif decision == "FAIL_PROJECTIVE_MMAX_GE_9":
        require(cert["proof_mode"] == "SMOOTH_PLUS_EXACT_REFINEMENT", "FAIL has wrong proof mode")
        require(census["exact_refinement_complete"] is True, "FAIL refinement incomplete")
        require(isinstance(witness, dict), "FAIL lacks witness")
        ids = witness.get("tuple_ids", [])
        require(len(ids) == 9 and len(set(ids)) == 9, "FAIL must carry nine distinct IDs")
        require(len(witness.get("common_projective_key_48_hex", "")) == 96, "bad exact key")
        require(error is None, "FAIL has error")
    elif decision == "REFINE_REQUIRED":
        require(cert["proof_mode"] == "NONE", "REFINE_REQUIRED has proof mode")
        require(census["smooth_mu_upper"] == "9+", "REFINE_REQUIRED lacks smooth saturation")
        require(census["nonzero_q_max"] == "9+" or census["zero_q_count"] == "5+", "no folded threshold crossed")
        require(census["exact_refinement_complete"] is False, "REFINE_REQUIRED says refined")
        require(census["exact_projective_max"] == "UNKNOWN", "bad exact status")
        require(witness is None and error is None, "REFINE_REQUIRED has witness/error")
    else:
        require(cert["proof_mode"] == "NONE", "ERROR has proof mode")
        require(isinstance(error, dict), "ERROR lacks error object")
        require(witness is None, "ERROR has mathematical witness")

    print(json.dumps({
        "decision": decision,
        "status": "STATIC_RESULT_ENVELOPE_PASS",
        "theorem_census_verified": False,
        "note": "Full PASS still requires independent regeneration of every declared shard and the 464 geometry."
    }, sort_keys=True))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"STATIC_RESULT_ENVELOPE_FAIL: {exc}", file=sys.stderr)
        raise SystemExit(1)
