#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from field_reference import (
    ETA, Q0, R, S, ONEL, U, encode_l48, f0_pow, l_from_small, l_mul, l_pow,
    f0_const, f0_sub, L,
)

E_SETS = {
    1: (0,1,2,3,5,11,12,13),
    2: (0,1,2,3,4,8,9,14),
    3: (0,1,2,4,5,7,11,14),
}
BASE_COLOR = {1:15, 2:9, 3:12}
P_EXPECTED = 52_747_567_104
FOLDED_EXPECTED = 26_373_783_552


def color(i:int,a:int)->int:
    return (BASE_COLOR[i] + 8*(a&1)) % 16

def tau_k(k:int)->int:
    i,a=divmod(k,16); i+=1
    if i==1: return 16 + ((a+6)&15)
    if i==2: return ((a+10)&15)
    return 32 + ((a+8)&15)

def l_sub(x:L,y:L)->L:
    return tuple(f0_sub(x[j],y[j]) for j in range(3))  # type: ignore[return-value]

def factor(t:int,i:int,a:int)->L:
    g=ONEL
    u2=l_mul(U,U)
    for e in E_SETS[i]:
        b=(a+e)&15
        root=f0_pow(ETA,2*t+16*b)
        g=l_mul(g,l_sub(u2,(root,f0_const(0),f0_const(0))))
    return g

def shell_count(first_options:tuple[int,...])->int:
    dp=[0]*16
    for k in first_options:
        i,a=divmod(k,16); i+=1
        dp[color(i,a)] += 1
    for _ in range(6):
        nd=[0]*16
        for c,n in enumerate(dp):
            if n:
                for k in range(48):
                    i,a=divmod(k,16); i+=1
                    nd[(c+color(i,a))%16] += n
        dp=nd
    return dp[4]

def main()->None:
    ap=argparse.ArgumentParser()
    ap.add_argument('table', type=Path)
    ap.add_argument('--skip-dlog-powers', action='store_true', help='structural smoke only; not theorem-grade')
    args=ap.parse_args()
    raw=args.table.read_bytes()
    obj=json.loads(raw)
    assert obj['schema']=='rs-mca.cycle87.u-slot-smooth-logs.v1'
    assert int(obj['smooth_order'])==S
    assert int(obj['hard_order'])==R
    gs=l_pow(l_pow(l_from_small(1,1,0),Q0-1),R)
    assert obj['smooth_generator_48_hex']==encode_l48(gs).hex()
    assert len(obj['records'])==336

    factors=[[None]*48 for _ in range(7)]
    logs=[[0]*48 for _ in range(7)]
    canonical=[]
    idx=0
    for t in range(1,8):
        for i in range(1,4):
            for a in range(16):
                rec=obj['records'][idx]; idx+=1
                k=16*(i-1)+a
                assert rec['t']==t and rec['i']==i and rec['a']==a and rec['k']==k
                assert rec['color']==color(i,a)
                g=factor(t,i,a)
                assert rec['factor_48_hex']==encode_l48(g).hex()
                ell=int(rec['smooth_log'])
                assert 0<=ell<S
                if not args.skip_dlog_powers:
                    h=l_pow(l_pow(g,Q0-1),R)
                    assert l_pow(gs,ell)==h
                factors[t-1][k]=g
                logs[t-1][k]=ell
                canonical.append({
                    't':t,'i':i,'a':a,'k':k,'color':color(i,a),
                    'smooth_log':str(ell),'factor_48_hex':encode_l48(g).hex(),
                })

    reps=tuple(list(range(16))+list(range(32,40)))
    assert all(k<tau_k(k) for k in reps)
    assert sorted(reps + tuple(tau_k(k) for k in reps)) == list(range(48))
    kappa=0
    tau_constants=[]
    for t in range(7):
        c=(logs[t][0]+logs[t][tau_k(0)])%S
        exact0=l_mul(factors[t][0],factors[t][tau_k(0)])
        for k in range(48):
            assert (logs[t][k]+logs[t][tau_k(k)])%S==c
            assert l_mul(factors[t][k],factors[t][tau_k(k)])==exact0
            i,a=divmod(k,16);i+=1
            j,b=divmod(tau_k(k),16);j+=1
            assert (color(i,a)+color(j,b))%16==8
        tau_constants.append(c)
        kappa=(kappa+c)%S
    delta=(kappa*((S+1)//2))%S
    assert [int(x) for x in obj['tau_slot_constants']]==tau_constants
    assert int(obj['tau_kappa'])==kappa
    assert int(obj['tau_delta'])==delta
    assert tuple(obj['canonical_first_options'])==reps
    assert int(obj['packet_count'])==P_EXPECTED
    assert int(obj['folded_packet_count'])==FOLDED_EXPECTED
    assert shell_count(tuple(range(48)))==P_EXPECTED
    assert shell_count(reps)==FOLDED_EXPECTED

    blob=json.dumps(canonical,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()+b'\n'
    out={
        'status':'U_SLOT_LOGS_VERIFY_PASS' if not args.skip_dlog_powers else 'U_SLOT_LOGS_STRUCTURAL_SMOKE_PASS',
        'file_sha256':hashlib.sha256(raw).hexdigest(),
        'canonical_records_sha256':hashlib.sha256(blob).hexdigest(),
        'records':len(canonical),
        'packet_count':str(P_EXPECTED),
        'folded_packet_count':str(FOLDED_EXPECTED),
        'canonical_first_options':list(reps),
        'tau_slot_constants':[str(x) for x in tau_constants],
        'tau_kappa':str(kappa),
        'tau_delta':str(delta),
    }
    print(json.dumps(out,sort_keys=True,indent=2))

if __name__=='__main__': main()
