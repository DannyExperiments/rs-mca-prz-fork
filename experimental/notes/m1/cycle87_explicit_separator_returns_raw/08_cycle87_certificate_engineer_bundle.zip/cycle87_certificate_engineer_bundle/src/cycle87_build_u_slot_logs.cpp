#include <array>
#include <vector>
#include <unordered_map>
#include <string>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <algorithm>
#include <numeric>
#include <cstdint>
#include <stdexcept>
#include <map>
using u128=unsigned __int128;
static constexpr int P=17;
struct F{std::array<uint8_t,16> c{}; bool operator==(F const&o)const{return c==o.c;}};
struct L{std::array<F,3> a{}; bool operator==(L const&o)const{return a==o.a;}};
F fzero(){return F{};} F fone(){F x;x.c[0]=1;return x;} F fconst(int a){F x;x.c[0]=(a%P+P)%P;return x;}
F fadd(F const&x,F const&y){F z;for(int i=0;i<16;i++)z.c[i]=(x.c[i]+y.c[i])%P;return z;}
F fsub(F const&x,F const&y){F z;for(int i=0;i<16;i++)z.c[i]=(x.c[i]+P-y.c[i])%P;return z;}
F fmul(F const&x,F const&y){int c[31]={};for(int i=0;i<16;i++)if(x.c[i])for(int j=0;j<16;j++)if(y.c[j])c[i+j]=(c[i+j]+x.c[i]*y.c[j])%P;for(int d=30;d>=16;--d){int v=c[d]%P;if(v){c[d]=0;c[d-8]=(c[d-8]-v)%P;if(c[d-8]<0)c[d-8]+=P;c[d-16]=(c[d-16]-3*v)%P;c[d-16]%=P;if(c[d-16]<0)c[d-16]+=P;}}F z;for(int i=0;i<16;i++)z.c[i]=c[i];return z;}
F fpow(F x,u128 e){F z=fone();while(e){if(e&1)z=fmul(z,x);x=fmul(x,x);e>>=1;}return z;}
F beta(){F b;b.c[0]=2;b.c[1]=1;return b;} F eta(){F e;e.c[9]=6;return e;}
L lzero(){return L{};} L lone(){L z;z.a[0]=fone();return z;} L lemb(F const&x){L z;z.a[0]=x;return z;} L U(){L z;z.a[1]=fone();return z;}
L ladd(L const&x,L const&y){L z;for(int i=0;i<3;i++)z.a[i]=fadd(x.a[i],y.a[i]);return z;}
L lsub(L const&x,L const&y){L z;for(int i=0;i<3;i++)z.a[i]=fsub(x.a[i],y.a[i]);return z;}
L lmul(L const&x,L const&y){L z;F B=beta();z.a[0]=fadd(fmul(x.a[0],y.a[0]),fmul(B,fadd(fmul(x.a[1],y.a[2]),fmul(x.a[2],y.a[1]))));z.a[1]=fadd(fadd(fmul(x.a[0],y.a[1]),fmul(x.a[1],y.a[0])),fmul(B,fmul(x.a[2],y.a[2])));z.a[2]=fadd(fadd(fmul(x.a[0],y.a[2]),fmul(x.a[1],y.a[1])),fmul(x.a[2],y.a[0]));return z;}
L lpow(L x,u128 e){L z=lone();while(e){if(e&1)z=lmul(z,x);x=lmul(x,x);e>>=1;}return z;}
std::string key(L const&x){std::string s; s.resize(48);int k=0;for(int j=0;j<3;j++)for(int i=0;i<16;i++)s[k++]=char(x.a[j].c[i]);return s;}
std::string hex48(L const&x){static char h[]="0123456789abcdef";std::string s;for(unsigned char b:key(x)){s+=h[b>>4];s+=h[b&15];}return s;}
std::string dec(u128 x){if(!x)return"0";std::string s;while(x){s.push_back('0'+x%10);x/=10;}std::reverse(s.begin(),s.end());return s;}
u128 modadd(u128 a,u128 b,u128 m){a+=b;if(a>=m)a-=m;return a;}
uint64_t inv64(uint64_t a,uint64_t m){int64_t t=0,nt=1;int64_t r=m,nr=a;while(nr){int64_t q=r/nr;int64_t tt=t-q*nt;t=nt;nt=tt;int64_t rr=r-q*nr;r=nr;nr=rr;}if(r!=1)throw std::runtime_error("no inverse");if(t<0)t+=m;return t;}
int color(int i,int a){static int s[4]={0,15,9,12};return (s[i]+8*(a&1))%16;}
int tauk(int k){int i=k/16+1,a=k%16;if(i==1)return 16+((a+6)&15);if(i==2)return ((a+10)&15);return 32+((a+8)&15);}
int main(){
  u128 A=1;for(int i=0;i<8;i++)A*=17;
  u128 q0=A*A,S=q0+A+1,R=q0-A+1;
  uint64_t ps[]={3,7,13,73,307,1321,72337,83233};
  L oneplusU=ladd(lone(),U()); L gs=lpow(lpow(oneplusU,q0-1),R);
  if(!(lpow(gs,S)==lone()))throw std::runtime_error("gs^S");
  for(auto p:ps)if(lpow(gs,S/p)==lone())throw std::runtime_error("bad gs order");
  std::vector<std::unordered_map<std::string,uint32_t>> tabs;
  for(auto p:ps){L gp=lpow(gs,S/p),cur=lone();std::unordered_map<std::string,uint32_t> tab;tab.reserve(p*2);for(uint32_t e=0;e<p;e++){auto ok=tab.emplace(key(cur),e);if(!ok.second)throw std::runtime_error("dlog dup");cur=lmul(cur,gp);}if(!(cur==lone()))throw std::runtime_error("subgroup order");tabs.push_back(std::move(tab));}
  int E[3][8]={{0,1,2,3,5,11,12,13},{0,1,2,3,4,8,9,14},{0,1,2,4,5,7,11,14}};
  std::array<std::array<L,48>,7> G; std::array<std::array<u128,48>,7> logs{};
  L u2=lmul(U(),U()); F et=eta();
  for(int t=1;t<=7;t++)for(int i=1;i<=3;i++)for(int aa=0;aa<16;aa++){
    L g=lone();for(int j=0;j<8;j++){int b=(aa+E[i-1][j])&15;F root=fpow(et,(u128)(2*t+16*b));g=lmul(g,lsub(u2,lemb(root)));}int k=(i-1)*16+aa;G[t-1][k]=g;
    L h=lpow(lpow(g,q0-1),R);std::vector<uint64_t> res;for(size_t z=0;z<8;z++){uint64_t p=ps[z];L hp=lpow(h,S/p);auto it=tabs[z].find(key(hp));if(it==tabs[z].end())throw std::runtime_error("dlog miss");res.push_back(it->second);}u128 x=0,M=1;for(size_t z=0;z<8;z++){uint64_t p=ps[z];uint64_t xr=(uint64_t)(x%p),Mr=(uint64_t)(M%p),diff=(res[z]+p-xr)%p;uint64_t q=(u128(diff)*inv64(Mr,p))%p;x+=M*q;M*=p;}x%=S;if(!(lpow(gs,x)==h))throw std::runtime_error("dlog verify");logs[t-1][k]=x;
  }
  // exact complement and smooth tau constants
  std::array<u128,7> tc{};u128 kappa=0;
  for(int t=0;t<7;t++){tc[t]=modadd(logs[t][0],logs[t][tauk(0)],S);for(int k=0;k<48;k++){if(modadd(logs[t][k],logs[t][tauk(k)],S)!=tc[t])throw std::runtime_error("tau log mismatch");L lhs=lmul(G[t][k],G[t][tauk(k)]);if(!(lhs==lmul(G[t][0],G[t][tauk(0)])))throw std::runtime_error("tau exact mismatch");}kappa=modadd(kappa,tc[t],S);}
  u128 inv2=(S+1)/2,delta=(kappa*inv2)%S;
  // exact shell DP and tau color identity
  for(int k=0;k<48;k++)if((color(k/16+1,k%16)+color(tauk(k)/16+1,tauk(k)%16))%16!=8)throw std::runtime_error("tau color");
  uint64_t dp[16]={};dp[0]=1;for(int t=0;t<7;t++){uint64_t nd[16]={};for(int c=0;c<16;c++)for(int k=0;k<48;k++)nd[(c+color(k/16+1,k%16))%16]+=dp[c];std::copy(nd,nd+16,dp);}if(dp[4]!=52747567104ULL)throw std::runtime_error("P count");
  std::vector<int> reps;for(int k=0;k<48;k++)if(k<tauk(k))reps.push_back(k);std::vector<int> expected;for(int k=0;k<16;k++)expected.push_back(k);for(int k=32;k<40;k++)expected.push_back(k);if(reps!=expected)throw std::runtime_error("canonical reps");
  uint64_t fdp[16]={};for(int k:reps)fdp[color(k/16+1,k%16)]++;for(int t=1;t<7;t++){uint64_t nd[16]={};for(int c=0;c<16;c++)for(int k=0;k<48;k++)nd[(c+color(k/16+1,k%16))%16]+=fdp[c];std::copy(nd,nd+16,fdp);}if(fdp[4]!=26373783552ULL)throw std::runtime_error("folded P count");
  std::cout<<"{\n  \"schema\": \"rs-mca.cycle87.u-slot-smooth-logs.v1\",\n";
  std::cout<<"  \"smooth_order\": \""<<dec(S)<<"\",\n  \"hard_order\": \""<<dec(R)<<"\",\n";
  std::cout<<"  \"smooth_generator_48_hex\": \""<<hex48(gs)<<"\",\n";
  std::cout<<"  \"tau_slot_constants\": [";for(int t=0;t<7;t++){if(t)std::cout<<",";std::cout<<"\""<<dec(tc[t])<<"\"";}std::cout<<"],\n";
  std::cout<<"  \"tau_kappa\": \""<<dec(kappa)<<"\",\n  \"tau_delta\": \""<<dec(delta)<<"\",\n";
  std::cout<<"  \"canonical_first_options\": [";for(size_t j=0;j<reps.size();j++){if(j)std::cout<<",";std::cout<<reps[j];}std::cout<<"],\n";
  std::cout<<"  \"packet_count\": \"52747567104\",\n  \"folded_packet_count\": \"26373783552\",\n";
  std::cout<<"  \"records\": [\n";
  bool first=true;for(int t=0;t<7;t++)for(int k=0;k<48;k++){if(!first)std::cout<<",\n";first=false;std::cout<<"    {\"t\":"<<t+1<<",\"i\":"<<k/16+1<<",\"a\":"<<k%16<<",\"k\":"<<k<<",\"color\":"<<color(k/16+1,k%16)<<",\"smooth_log\":\""<<dec(logs[t][k])<<"\",\"factor_48_hex\":\""<<hex48(G[t][k])<<"\"}";}
  std::cout<<"\n  ]\n}\n";
}
