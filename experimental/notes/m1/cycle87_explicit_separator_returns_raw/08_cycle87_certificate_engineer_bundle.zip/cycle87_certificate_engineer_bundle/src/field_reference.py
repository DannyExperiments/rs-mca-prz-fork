#!/usr/bin/env python3
"""Independent stdlib reference checks for the Cycle87 separator field.

This is deliberately small and slow.  It is not the 52.7-billion-record
producer.  It fixes the byte/arithmetic conventions and verifies the group
factorization used by the smooth-projective domination census.
"""
from __future__ import annotations

from dataclasses import dataclass
from math import gcd, isqrt
import json

P = 17
D0 = 16
A = 17**8
Q0 = 17**16
QLINE = 17**48
QPROJ = Q0**2 + Q0 + 1
S = Q0 + A + 1
R = Q0 - A + 1
S_FACTORS = (3, 7, 13, 73, 307, 1321, 72337, 83233)
R_MINUS_1_FACTORS = {2: 7, 3: 2, 5: 1, 17: 8, 29: 1, 41761: 1}
PACKETS = 52_747_567_104
OCCUPIED = 52_747_567_092
TARGET = QLINE // 2**128

F0 = tuple[int, ...]
L = tuple[F0, F0, F0]

ZERO0: F0 = (0,) * D0
ONE0: F0 = (1,) + (0,) * (D0 - 1)
BETA: F0 = (2, 1) + (0,) * 14
ETA: F0 = (0,) * 9 + (6,) + (0,) * 6
ZEROL: L = (ZERO0, ZERO0, ZERO0)
ONEL: L = (ONE0, ZERO0, ZERO0)
U: L = (ZERO0, ONE0, ZERO0)




# Polynomial helpers over F_17, ascending coefficients, for Rabin irreducibility.
def fp_trim(a: list[int]) -> list[int]:
    a = [x % P for x in a]
    while len(a) > 1 and a[-1] == 0:
        a.pop()
    return a


def fp_sub(a: list[int], b: list[int]) -> list[int]:
    n = max(len(a), len(b))
    return fp_trim([((a[i] if i < len(a) else 0) - (b[i] if i < len(b) else 0)) % P for i in range(n)])


def fp_mul(a: list[int], b: list[int]) -> list[int]:
    c = [0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            c[i+j] = (c[i+j] + x*y) % P
    return fp_trim(c)


def fp_divmod(a: list[int], b: list[int]) -> tuple[list[int], list[int]]:
    aa, bb = fp_trim(a), fp_trim(b)
    assert bb != [0]
    if len(aa) < len(bb):
        return [0], aa
    q = [0] * (len(aa)-len(bb)+1)
    inv = pow(bb[-1], P-2, P)
    while aa != [0] and len(aa) >= len(bb):
        d = len(aa)-len(bb)
        c = aa[-1]*inv % P
        q[d] = c
        for j, x in enumerate(bb):
            aa[d+j] = (aa[d+j]-c*x) % P
        aa = fp_trim(aa)
    return fp_trim(q), aa


def fp_mod(a: list[int], f: list[int]) -> list[int]:
    return fp_divmod(a, f)[1]


def fp_powmod(a: list[int], e: int, f: list[int]) -> list[int]:
    z = [1]
    a = fp_mod(a, f)
    while e:
        if e & 1:
            z = fp_mod(fp_mul(z, a), f)
        a = fp_mod(fp_mul(a, a), f)
        e >>= 1
    return z


def fp_gcd(a: list[int], b: list[int]) -> list[int]:
    aa, bb = fp_trim(a), fp_trim(b)
    while bb != [0]:
        aa, bb = bb, fp_divmod(aa, bb)[1]
    inv = pow(aa[-1], P-2, P)
    return fp_trim([(inv*x) % P for x in aa])


def verify_f0_modulus_irreducible() -> None:
    f = [3] + [0]*7 + [1] + [0]*7 + [1]
    x = [0,1]
    assert fp_powmod(x, P**16, f) == x
    # 16 has only one prime divisor, 2.
    assert fp_gcd(fp_sub(fp_powmod(x, P**8, f), x), f) == [1]


def f0_add(x: F0, y: F0) -> F0:
    return tuple((a + b) % P for a, b in zip(x, y))


def f0_sub(x: F0, y: F0) -> F0:
    return tuple((a - b) % P for a, b in zip(x, y))


def f0_mul(x: F0, y: F0) -> F0:
    c = [0] * 31
    for i, a in enumerate(x):
        if not a:
            continue
        for j, b in enumerate(y):
            if b:
                c[i + j] = (c[i + j] + a * b) % P
    # X^16 + X^8 + 3 = 0, so X^d = -X^(d-8)-3X^(d-16).
    for d in range(30, 15, -1):
        a = c[d]
        if a:
            c[d] = 0
            c[d - 8] = (c[d - 8] - a) % P
            c[d - 16] = (c[d - 16] - 3 * a) % P
    return tuple(c[:16])


def f0_pow(x: F0, e: int) -> F0:
    z = ONE0
    while e:
        if e & 1:
            z = f0_mul(z, x)
        x = f0_mul(x, x)
        e >>= 1
    return z


def l_add(x: L, y: L) -> L:
    return tuple(f0_add(x[i], y[i]) for i in range(3))  # type: ignore[return-value]


def l_mul(x: L, y: L) -> L:
    x0, x1, x2 = x
    y0, y1, y2 = y
    z0 = f0_add(f0_mul(x0, y0), f0_mul(BETA, f0_add(f0_mul(x1, y2), f0_mul(x2, y1))))
    z1 = f0_add(f0_add(f0_mul(x0, y1), f0_mul(x1, y0)), f0_mul(BETA, f0_mul(x2, y2)))
    z2 = f0_add(f0_add(f0_mul(x0, y2), f0_mul(x1, y1)), f0_mul(x2, y0))
    return (z0, z1, z2)


def l_pow(x: L, e: int) -> L:
    z = ONEL
    while e:
        if e & 1:
            z = l_mul(z, x)
        x = l_mul(x, x)
        e >>= 1
    return z


def f0_const(a: int) -> F0:
    return (a % P,) + (0,) * 15


def l_from_small(a0: int, a1: int, a2: int) -> L:
    return (f0_const(a0), f0_const(a1), f0_const(a2))


def is_prime_trial(n: int) -> bool:
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    d = 3
    while d * d <= n:
        if n % d == 0:
            return False
        d += 2
    return True


def verify_r_pocklington() -> None:
    product = 1
    for p, e in R_MINUS_1_FACTORS.items():
        assert is_prime_trial(p)
        product *= p**e
    assert product == R - 1
    # Complete factorization of R-1, with one common witness.
    witness = 7
    assert pow(witness, R - 1, R) == 1
    for p in R_MINUS_1_FACTORS:
        assert gcd(pow(witness, (R - 1) // p, R) - 1, R) == 1
    # Pocklington's F is R-1 > sqrt(R), so R is prime.
    assert R - 1 > isqrt(R)


def encode_l48(x: L) -> bytes:
    """48 bytes: U-block, then X coefficient; all coefficients 0..16."""
    return bytes(c for block in x for c in block)


def main() -> None:
    verify_f0_modulus_irreducible()
    assert Q0 == A * A
    assert QPROJ == S * R
    assert S == 48_661_191_882_642_625_923
    assert R == 48_661_191_868_691_111_041
    assert all(is_prime_trial(p) for p in S_FACTORS)
    sf = 1
    for p in S_FACTORS:
        sf *= p
    assert sf == S
    verify_r_pocklington()

    assert f0_pow(ETA, 256) == ONE0
    assert f0_pow(ETA, 128) != ONE0
    assert f0_pow(ETA, 17**8) != ETA
    assert f0_pow(BETA, 256) != ONE0
    noncube = f0_pow(BETA, (Q0 - 1) // 3)
    expected_noncube = (2,) + (0,) * 7 + (5,) + (0,) * 7
    assert noncube == expected_noncube != ONE0
    assert l_mul(U, l_mul(U, U)) == (BETA, ZERO0, ZERO0)

    # Smooth subgroup generator: g_s = ((1+U)^(q0-1))^R.
    gs = l_pow(l_pow(l_from_small(1, 1, 0), Q0 - 1), R)
    assert l_pow(gs, S) == ONEL
    for p in S_FACTORS:
        assert l_pow(gs, S // p) != ONEL

    numerator = PACKETS * OCCUPIED
    conservative = numerator // 8
    assert numerator % 8 == 0
    assert conservative == 347_788_229_344_751_517_696
    assert TARGET == 338_617_018_271_848_945_628
    assert conservative - TARGET == 9_171_211_072_902_572_068

    out = {
        "status": "FIELD_REFERENCE_SELFTEST_PASS",
        "p": P,
        "q0": str(Q0),
        "q_line": str(QLINE),
        "projective_group_order": str(QPROJ),
        "smooth_order": str(S),
        "hard_prime_order": str(R),
        "smooth_factors": list(S_FACTORS),
        "r_minus_1_factorization": {str(k): v for k, v in R_MINUS_1_FACTORS.items()},
        "beta_noncube_coeffs": list(noncube),
        "smooth_generator_48_hex": encode_l48(gs).hex(),
        "P_times_N_over_8": str(conservative),
        "T_line": str(TARGET),
        "margin": str(conservative - TARGET),
    }
    print(json.dumps(out, sort_keys=True, indent=2))


if __name__ == "__main__":
    main()
