# Cycle87 explicit separator replay specification

## 0. Scope and decision semantics

This bundle specifies the next deterministic replay for

```text
V-CYCLE86-U-PROJECTIVE-MMAX8-CENSUS
```

at the concrete separator

```text
F0 = F_17[X]/(X^16+X^8+3),
beta = X+2,
L = F0[U]/(U^3-beta),
y = U,
c = beta-U.
```

The 336-row extension-field setup has been generated twice and independently
verified.  The preferred 464 geometry has also been materialized and verified.
Only the expensive folded census remains unexecuted in this bundle.  Allowed final decisions are:

* `PASS`: all folded census shards are complete; either the smooth threshold
  passes or every threshold-crossing key has exact projective refinement;
  `mu_proj(U)<=8`; the 464 construction is verified; and the official finite
  target is cleared.
* `FAIL_PROJECTIVE_MMAX_GE_9`: nine distinct admissible tuples have one exact
  projective key.  This disproves `mu_proj(U)<=8` for the candidate `U`.
* `REFINE_REQUIRED`: at least one folded smooth key crossed its coarse
  threshold, but exact projective refinement is incomplete.  This is neither
  PASS nor FAIL.
* `ERROR`: dependency, arithmetic, coverage, geometry, schema, or resource
  failure.  It carries no mathematical implication.

An aggregate JSON cannot prove absence of a ninth collision by itself.  A
PASS requires independent regeneration of every declared shard.

## 1. Exact reductions

### 1.1 Smooth-projective domination

Put

```text
q0 = 17^16 = 48,661,191,875,666,868,481,
G = L^x/F0^x,
|G| = q0^2+q0+1.
```

With `a=17^8=6,975,757,441`,

```text
|G| = (q0+a+1)(q0-a+1) = S*r,
S = 48,661,191,882,642,625,923
  = 3*7*13*73*307*1321*72337*83233,
r = 48,661,191,868,691,111,041.
```

The complete factorization

```text
r-1 = 2^7*3^2*5*17^8*29*41761
```

with Pocklington witness `7` proves that `r` is prime.

For nonzero `b in L`, define

```text
z(b)=b^(q0-1),
s(b)=z(b)^r.
```

The kernel of `b -> z(b)` is exactly `F0^x`, so `z` is a canonical exact
projective key.  The image of `s` has order `S`.  If

```text
mu_s(U)=max_g #{T in P0:s(P_T(U))=g},
```

then

```text
mu_proj(U) <= mu_s(U).
```

Proof: every exact projective fiber is contained in a fiber of the group
homomorphism `[b] -> [b]^r`.  No converse is used.  Hence a complete proof
`mu_s(U)<=8` is already sufficient, while a smooth collision is only a
refinement trigger.

Use the deterministic generator

```text
g_s=((1+U)^(q0-1))^r.
```

The verifier checks `g_s^S=1` and `g_s^(S/p)!=1` for every prime `p|S`.

### 1.2 Exact tau folding

For an option `k=16(i-1)+a`, define

```text
tau(1,a)=(2,a+6),
tau(2,a)=(1,a+10),
tau(3,a)=(3,a+8)                 (a modulo 16).
```

For every slot `t`, the explicit root sets satisfy

```text
G[t,k](U) G[t,tau(k)](U) = C_t(U),
log_s G[t,k] + log_s G[t,tau(k)] = kappa_t mod S.
```

The color rule satisfies `color(k)+color(tau(k))=8 mod16`; therefore tau
preserves the seven-slot color-4 shell because `7*8-4=52=4 mod16`.

Set

```text
kappa=sum_t kappa_t mod S
     =13,943,676,897,899,455,034,
delta=kappa/2 mod S
     = 6,971,838,448,949,727,517.
```

For tuple exponent `e(T)`, let

```text
x(T)=e(T)-delta mod S,
q(T)=min(x(T),S-x(T)).
```

Since `S` is odd, `q` lies in

```text
0 <= q < H=(S+1)/2=24,330,595,941,321,312,962.
```

The first-slot condition `k1<tau(k1)` selects precisely

```text
{0,...,15,32,...,39}
```

and exactly one tuple from every tau orbit.  Let `n(q)` be the number of these
canonical tuples at folded key `q`.  Then

```text
q>0: multiplicity_s(delta+q)=multiplicity_s(delta-q)=n(q),
q=0: multiplicity_s(delta)=2 n(0).
```

Consequently

```text
mu_s(U)<=8
iff
n(q)<=8 for every q>0 and n(0)<=4.
```

This is an exact equivalence, not a heuristic.  It reduces the primary scan
from `52,747,567,104` to `26,373,783,552` records.

## 2. Source files and language choices

The production repository should preserve these trust boundaries:

```text
cpp/ff17_16.hpp
cpp/ff17_48.hpp
cpp/cycle87_build_u_slot_logs.cpp
cpp/cycle87_tau_folded_scan.cpp
cpp/cycle87_exact_refine.cpp
python/verify_field_and_slot_logs.py
python/verify_static_and_geometry.py
rust/src/bin/verify_shard.rs
schemas/cycle87_result.schema.json
schemas/cycle87_shard.schema.json
inputs/INPUTS.lock.json
scripts/reproduce.sh
README.md
```

* **C++20 producer:** field arithmetic, Pohlig--Hellman setup, sorted MITM side
  tables, interval-sharded folded enumeration, exact open-address counting,
  and exact refinement.  No floating point or randomized seed.
* **Python 3 standard-library verifier:** separately reconstructs `F0`, `L`,
  all 336 factors, every smooth exponent identity, input hashes, 464 geometry,
  witnesses, and threshold arithmetic.  The included verifier performs the
  complete 336-row setup audit.
* **Rust independent shard verifier:** separately written arithmetic and tuple
  enumeration, used to regenerate each expensive shard and compare counts and
  hashes.  A Python external-sort implementation may be retained as a slow
  reference but must not be the sole expensive-path verifier.

Sage may assist development but is outside the trusted replay path.

## 3. Finite-field representation

### 3.1 Base field

An `F0` element is the 16-byte coefficient vector

```text
(a0,...,a15), 0<=ai<17,
```

in increasing powers of `X`.  Reduction uses

```text
X^16=-X^8-3=16X^8+14 mod17.
```

The verifier proves irreducibility by Rabin's criterion and checks

```text
eta=6X^9, ord(eta)=256,
beta=X+2 notin <eta>,
beta^((q0-1)/3)=2+5X^8 !=1.
```

The last identity proves `U^3-beta` irreducible.

### 3.2 Cubic extension

An `L` element is

```text
b0+b1 U+b2 U^2, bi in F0,
```

encoded as 48 bytes in `(U block, X coefficient)` order.  Multiplication is

```text
c0=a0b0+beta(a1b2+a2b1),
c1=a0b1+a1b0+beta a2b2,
c2=a0b2+a1b1+a2b0.
```

All arithmetic is exact modulo 17.  Exponentiation is binary square-and-
multiply.

### 3.3 Keys

```text
exact_projective_key(b)=encode48(b^(q0-1)),
smooth_element(b)=b^((q0-1)r).
```

The smooth element is represented by its exact discrete log to `g_s` in
`[0,S)`.  The exact key is the canonical 48-byte witness key.

## 4. Input artifacts and generated setup

The authoritative packet definition is the pinned Cycle68/Cycle84 model
source.  `inputs/INPUTS.lock.json` pins the context, model source, original
slot verification, exact `m_max=2` certificate, collision list, public replay
result, and acceptance certificate.  Raw Cycle86 worker hashes without bytes
are explicitly excluded.

From the authoritative root sets, reconstruct in order

```text
t=1..7, i=1..3, a=0..15,
G[t,i,a](U)=product_{b in a+E_i mod16}(U^2-eta^(2t+16b)).
```

Up to the common factor `U-1`, every locator has projective class

```text
[P_T(U)]=[product_t G[t,i_t,a_t](U)].
```

The common factor translates all cyclic logs by a constant and does not alter
multiplicity or folded keys.

The included executable setup producer emits

```text
examples/cycle87_u_slot_smooth_logs.json
sha256 bc9e8ef7dfe4fc8cca89e82b3ec150a12ec0cfbe1be3e641b62b05e623ba9987.
```

The independent verifier checks every row by reconstructing the factor and
verifying

```text
g_s^ell = G[t,i,a](U)^((q0-1)r).
```

The canonical compact record hash is

```text
54c9af836c48a7a8bfa40b8121a82b8c25c180feb8387f371aba2772b7913670.
```

The old Cycle84 `slot_logs.json` is only a model cross-check; its base-field
logs at `beta` are never reused as `U` logs.

## 5. Folded MITM census and memory-bounded sharding

Build the sides

```text
folded left: 24*48^2 = 55,296 records,
right:       48^4    = 5,308,416 records.
```

Right records are sorted in 16 color buckets by `(smooth_log,local_id)`.  The
mandatory compatibility total is

```text
sum_l |R_(4-color(l))| = 26,373,783,552.
```

Pack a full tuple as seven six-bit options in a 42-bit integer.  Unused high
bits are zero.

Partition the folded key space `[0,H)` into `M=1536` intervals

```text
I_s=[floor(Hs/M),floor(H(s+1)/M)).
```

The largest interval width is

```text
15,840,231,732,631,064 < 2^54.
```

For a left log `ell` and shard `[lo,hi)`, the centered residues are exactly

```text
[lo,hi)
union
[S-hi+1,S-max(lo,1)+1)       when max(lo,1)<hi.
```

Shift these intervals by `delta-ell` modulo `S`.  This gives at most four
ordinary sorted right-log ranges, each found by two binary searches.  Every
canonical compatible pair enters exactly one shard and one folded key.

For each shard:

1. perform a cheap count-only pass using binary-search range lengths;
2. allocate an exact open-address table at load at most 0.65;
3. enumerate the records and store the **full shard-local offset**, never only
   a hash;
4. saturate counts at 9;
5. mark `q=0` saturated at canonical count 5 and `q>0` saturated at count 9;
6. emit immutable JSON, a sorted local-offset file, SHA-256 values, and only
   then a `.done` marker.

A 64-bit table word may use bits `0..55` for `offset+1` and bits `56..63` for
the count.  At the default sharding, the average record count is exactly
`17,170,432`; a typical table occupies about 256 MiB.  Lower-memory runners may
increase `M`, which is certificate data.

Absolute folded keys can require 65 bits.  Saturated-key binary files therefore
store 64-bit little-endian **local offsets**; the shard's decimal `lower`
reconstructs the absolute key.  Storing an absolute key in `uint64_t` is
forbidden.

The merge verifies a disjoint partition of `[0,H)`, common dependency hashes,
all `.done` markers, and

```text
sum shard.record_count = 26,373,783,552.
```

A smooth PASS requires

```text
max_{q>0} n(q)<=8 and n(0)<=4.
```

## 6. Exact refinement and PASS/FAIL certificates

A threshold-crossing smooth key is not FAIL.  Re-enumerate it from the side
tables.

For `q>0`, normalize each canonical orbit representative into the `delta+q`
smooth fiber:

```text
x=e-delta=q: keep T,
x=e-delta=S-q: replace T by tau(T).
```

For `q=0`, include both `T` and `tau(T)`, since both lie in the same smooth
fiber.  Compute

```text
z_T=P_T(U)^(q0-1)
```

including the common `U-1` factor, sort `(z_T,tuple_id)`, and run-length encode.

* If every exact run has length at most 8, emit PASS with
  `proof_mode=SMOOTH_PLUS_EXACT_REFINEMENT`.
* If one exact run reaches 9, emit `FAIL_PROJECTIVE_MMAX_GE_9` with exactly
  nine distinct tuple IDs and the common 96-hex-character key.  The independent
  verifier reconstructs all nine locators and checks equality.
* If any saturated key remains unrefined, emit `REFINE_REQUIRED`.

A FAIL cuts only `y=U` and the `mu<=8` shortcut; it does not prove that every
separator fails or that the actual slope count is below target.

## 7. The shortened 464 construction verifier

The separator PASS is spliced to the preferred package

```text
(n,k,sigma,j)=(464,232,6,226).
```

### 7.1 Domain

Let

```text
D=<eta>, |D|=256,
Z0={eta^(8b):1<=b<=24},
Dminus=D\Z0, |Dminus|=232,
c=beta-U,
D2=Dminus union (c+Dminus).
```

Use the order

```text
Dminus in increasing eta exponent, followed by c+Dminus in the same order.
```

The verifier checks:

* every packet option avoids `Z0`, hence every packet support survives;
* all 464 entries are distinct;
* `beta` is not in the domain;
* `eta` remains, has degree 16 over `F17`, and generates `F0`;
* from `d` and `c+d` the domain generates `c`, then `U=beta-c`, so it
  generates `L`.

The included executable `src/verify_geometry_464.py` performs all of these
checks.  The ordered domain hash is

```text
6aa1eb735afbaaf36eefb3ac080123fb49c9e32d0dd861cd635c54ad42991f76.
```

If universal avoidance fails, the 464 theorem is not certified and the replay
must fall back to the separately specified 560 package.  It must not silently
remove a different set.

### 7.2 Common six-jet

For `J_T(t)=product_{x in T}(1-xt)`, verify the banked packet identity

```text
J_T(t)=1-t mod t^6.
```

This can be checked over the implicit option model by dynamic programming on
`(slot,color,jet_coefficients)`; it does not require listing all `P` tuples.
Then

```text
J_(c+T)(t)
  =(1-ct)^113 J_T(t/(1-ct))
  =(1-ct)^112(1-(c+1)t) mod t^6,
```

and every combined support has the fixed jet

```text
J_S(t)=(1-t)(1-ct)^112(1-(c+1)t) mod t^6.
```

Compute

```text
J_S(t)^(-1)=h0+h1 t+...+h5 t^5 mod t^6.
```

### 7.3 One GRS code and one syndrome line

For each domain point `x`, define

```text
H_x=(1,x,...,x^230,(beta-x)^(-1))^T in L^232.
```

After multiplying column `x` by `beta-x`, the rows evaluate

```text
(beta-Y),Y(beta-Y),...,Y^230(beta-Y),1,
```

which form a basis of `L[Y]_{<=231}`.  Hence this is one `[464,232]` GRS code,
not a direct sum.

The exact column-major matrix hash is

```text
5ee34d5a29e09180fa82d09ea07abec9006cdead736ce1c9506b76a887f7bcce.
```

Set

```text
s=(0 repeated 225 times,h0,h1,...,h5) in L^231,
ell(z)=(s,z) in L^232.
```

For any combined support `S` of size 226, use coefficients

```text
a_x=1/P_S'(x), x in S.
```

The verifier checks the partial-fraction identities

```text
sum a_x x^m = 0,                    0<=m<=224,
sum a_x x^(225+r) = h_r,            0<=r<=5,
sum a_x/(beta-x) = 1/P_S(beta).
```

Thus every support represents one point of the single affine line, with slope

```text
z_S=1/P_S(beta)
   =1/(rho(T1) P_T2(U)).
```

All coefficients are nonzero.  If the line direction lay in the span of the
226 support columns, projection to the first 231 rows would yield a dependence
among 226 distinct Vandermonde columns.  The first 226 rows already form an
invertible square Vandermonde matrix, so the incidence is transverse.

The base-and-direction affine-line hash is

```text
6b49252971502a27e49a673b20f3ed2457557432232eb8116f56da602e272e2a.
```

The executable additionally checks all 336 option-block jets and one complete
226-support barycentric syndrome identity, including the reciprocal row.  Its
certificate is `examples/cycle87_geometry_464_certificate.json`; consequently
the 560 fallback is not needed for the explicit model.

### 7.4 Numerator

Use one first-copy representative for each of the `N=52,747,567,092` occupied
`rho` values, obtained by dropping the lexicographically larger tuple from
all twelve certified double fibers.  Use all `P=52,747,567,104` second-copy
packet supports.

If two pair products agree, their second-copy locator values are `F0`-
proportional.  For a fixed second support the first `rho` value is uniquely
determined.  Therefore every pair-product fiber has size at most
`mu_proj(U)`, and

```text
#distinct slopes >= ceil(NP/mu_proj(U)).
```

Under `mu_proj(U)<=8`, the conservative exact lower bound is

```text
NP/8 = 347,788,229,344,751,517,696.
```

The official denominator is

```text
q_line=17^48,
T_line=floor(q_line/2^128)=338,617,018,271,848,945,628,
margin=9,171,211,072,902,572,068.
```

`q0=17^16` is only the internal base field.  For this explicit instance,
`q_gen=q_code=q_line=17^48`; record `q_chal=17^48` only because the challenge
instance itself is declared over the same field.  `q_chal` is never substituted
for `q_line` in the threshold.

## 8. Output certificate JSON

The normative schemas are

```text
schemas/cycle87_result.schema.json
schemas/cycle87_shard.schema.json
schemas/cycle87_geometry_464.schema.json.
```

The result records:

* exact field, separator, smooth factorization, generator, tau constants, and
  folded key-space size;
* every dependency path, SHA-256, and verification flag;
* full and folded packet counts, side-table sizes, slot-table hashes;
* shard count, full-domain flag, enumerated and logical record counts;
* `nonzero_q_max`, `zero_q_count`, smooth upper bound, refinement status, and
  exact projective upper bound;
* 464 domain/code/line hashes and all geometry booleans;
* `q_gen`, `q_code`, `q_line`, `q_chal`, target, numerator, and margin;
* finite/model/public-replay classification;
* either nine exact witnesses, an operational error, or neither.

Canonical JSON is UTF-8

```python
json.dumps(obj,sort_keys=True,separators=(",",":"),ensure_ascii=True)+"\n".
```

Large integers are decimal strings.  `result_payload_sha256` hashes the
canonical object with that field replaced by 64 ASCII zeroes.

## 9. Independent verifier contract

A theorem-grade verifier performs, in order:

1. hash every input against `INPUTS.lock.json` and reject substitutions;
2. reconstruct `F0` and `L`, prove irreducibility, and verify `eta`, `beta`;
3. verify `|G|=Sr`, the Pocklington certificate for `r`, and order of `g_s`;
4. reconstruct all 336 factors and verify every smooth log independently;
5. verify exact tau products, colors, `kappa`, `delta`, canonical first options,
   and both shell counts;
6. rebuild the folded MITM side tables and their cryptographic digests;
7. independently regenerate every shard, including `q=0`, maxima, saturation
   lists, record digests, and exact global total;
8. apply smooth domination or exact refinement according to the decision;
9. for FAIL, reconstruct nine full locators and their exact keys;
10. verify the 464 domain, common jet, GRS basis, line, transversality, selector,
    and slope-fiber implication;
11. recompute the numerator and target using unbounded integers;
12. validate the result schema and emit a separate acceptance JSON covering the
    result, manifest, source tree, compiler versions, and commands.

The verifier rejects PASS if any shard is smoke-only, truncated, lacks a valid
`.done`, has inconsistent interval count, uses another slot table or tuple
ordering, or is not independently regenerated.

## 10. Reviewer reproduction

Local setup and 464-geometry replay:

```bash
./scripts/reproduce.sh
```

The intended public theorem workflow is:

```bash
sha256sum -c inputs/SHA256SUMS.public
python3 python/verify_field_and_slot_logs.py --inputs inputs --out build/slot-audit.json
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j2

./build/cycle87_tau_folded_scan setup --out work/setup.json
for s in $(seq 0 1535); do
  ./build/cycle87_tau_folded_scan shard --id "$s" --count 1536 --work work
done
./build/cycle87_tau_folded_scan merge --work work --out work/result.json

# Invoked only if a folded key crosses 5 at q=0 or 9 at q>0.
./build/cycle87_exact_refine --work work --result work/result.json

python3 python/verify_static_and_geometry.py --result work/result.json --work work
cargo run --release --bin verify_shard -- --all --result work/result.json --work work
./scripts/finalize.sh work/result.json work/acceptance.json
```

A GitHub Actions matrix may process immutable shard ranges.  The acceptance job
must download and independently replay every shard; job summaries are not
evidence.

## 11. Exact conversion to proof or counterpacket

The next checker is

```text
V-CYCLE87-U-TAU-FOLDED-SMOOTH-MMAX8-CENSUS.
```

It yields PROOF when

```text
all 26,373,783,552 folded records are covered,
n(q)<=8 for q>0,
n(0)<=4,
```

or when every threshold-crossing key refines to exact projective runs of size
at most 8.  The included geometry certificate discharges
`V-CYCLE87-464-GRS-LINE` for the explicit model.  Thus a folded-census PASS,
followed by public replay, proves the explicit two-copy finite counterpacket.

It yields COUNTERPACKET against the candidate `U` when exact refinement emits
nine distinct tuples with one exact key.  The first currently unproved line in
the chain is precisely this folded census inequality; all reductions before it
are checkable from the included setup and pinned model.
