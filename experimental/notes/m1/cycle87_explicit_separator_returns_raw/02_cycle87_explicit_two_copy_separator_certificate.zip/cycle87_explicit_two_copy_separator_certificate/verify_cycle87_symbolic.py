#!/usr/bin/env python3
"""Fast exact verifier for the Cycle87 U-separator and 464-point GRS materialization.

This verifies finite-field definitions, the canonical 336 slot-factor table,
the shortened 464-point domain, the common syndrome line, the projection-log
bridge, all census-part hashes/totals, and the 2^-128 threshold arithmetic.
It does not rerun the 52.7-billion-record census; REPRODUCE_CYCLE87.sh does.
"""
from __future__ import annotations
import hashlib, json, math, os, re, sys
from pathlib import Path

PCHAR=17
DEG=16
ZERO_F=(0,)*DEG
ONE_F=(1,)+(0,)*(DEG-1)

# ---------- generic polynomial arithmetic over F_17 (for irreducibility) ----------
def trim(a):
    a=list(a)
    while len(a)>1 and a[-1]%PCHAR==0:a.pop()
    return [x%PCHAR for x in a]
def padd(a,b):
    n=max(len(a),len(b));r=[0]*n
    for i in range(n):r[i]=((a[i] if i<len(a) else 0)+(b[i] if i<len(b) else 0))%PCHAR
    return trim(r)
def psub(a,b):
    n=max(len(a),len(b));r=[0]*n
    for i in range(n):r[i]=((a[i] if i<len(a) else 0)-(b[i] if i<len(b) else 0))%PCHAR
    return trim(r)
def pmul(a,b):
    r=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):r[i+j]=(r[i+j]+x*y)%PCHAR
    return trim(r)
def pdivmod(a,b):
    a=trim(a);b=trim(b);assert b!=[0]
    q=[0]*max(1,len(a)-len(b)+1);ib=pow(b[-1],-1,PCHAR)
    while len(a)>=len(b) and a!=[0]:
        d=len(a)-len(b);c=a[-1]*ib%PCHAR;q[d]=c
        for i in range(len(b)):a[d+i]=(a[d+i]-c*b[i])%PCHAR
        a=trim(a)
    return trim(q),trim(a)
def pmod(a,m):return pdivmod(a,m)[1]
def ppowmod(a,e,m):
    r=[1];a=pmod(a,m)
    while e:
        if e&1:r=pmod(pmul(r,a),m)
        a=pmod(pmul(a,a),m);e//=2
    return r
def pgcd(a,b):
    a=trim(a);b=trim(b)
    while b!=[0]:a,b=b,pmod(a,b)
    inv=pow(a[-1],-1,PCHAR)
    return trim([(x*inv)%PCHAR for x in a])

# ---------- F0 = F_17[X]/(X^16+X^8+3) ----------
def fc(n:int):
    z=[0]*DEG;z[0]=n%PCHAR;return tuple(z)
def fadd(a,b):return tuple((a[i]+b[i])%PCHAR for i in range(DEG))
def fsub(a,b):return tuple((a[i]-b[i])%PCHAR for i in range(DEG))
def fneg(a):return tuple((-x)%PCHAR for x in a)
def fmul(a,b):
    w=[0]*(2*DEG-1)
    for i,x in enumerate(a):
        if x:
            for j,y in enumerate(b):
                if y:w[i+j]+=x*y
    # X^16 = -X^8-3
    for k in range(30,15,-1):
        c=w[k]%PCHAR
        if c:
            w[k-8]-=c;w[k-16]-=3*c
    return tuple(x%PCHAR for x in w[:DEG])
def fpow(a,e:int):
    r=ONE_F
    while e:
        if e&1:r=fmul(r,a)
        a=fmul(a,a);e//=2
    return r

# ---------- L = F0[U]/(U^3-beta) ----------
ZERO_L=(ZERO_F,ZERO_F,ZERO_F)
ONE_L=(ONE_F,ZERO_F,ZERO_F)
def lfrom(a):return (a,ZERO_F,ZERO_F)
def ladd(a,b):return tuple(fadd(a[i],b[i]) for i in range(3))
def lsub(a,b):return tuple(fsub(a[i],b[i]) for i in range(3))
def lneg(a):return tuple(fneg(a[i]) for i in range(3))
def lmul(a,b):
    w=[ZERO_F for _ in range(5)]
    for i in range(3):
        for j in range(3):w[i+j]=fadd(w[i+j],fmul(a[i],b[j]))
    w[1]=fadd(w[1],fmul(w[4],BETA))
    w[0]=fadd(w[0],fmul(w[3],BETA))
    return (w[0],w[1],w[2])
def lpow(a,e:int):
    r=ONE_L
    while e:
        if e&1:r=lmul(r,a)
        a=lmul(a,a);e//=2
    return r
def lscale(a,n:int):return lmul(lfrom(fc(n)),a)
def lencode(a):return bytes(x for f in a for x in f)
def lhex(a):return lencode(a).hex()

# truncated polynomials over L
def lpoly_mul(a,b,N=6):
    r=[ZERO_L]*N
    for i,x in enumerate(a):
        if i>=N:break
        for j,y in enumerate(b):
            if i+j>=N:break
            r[i+j]=ladd(r[i+j],lmul(x,y))
    return r
def lpoly_pow(a,e,N=6):
    r=[ONE_L]+[ZERO_L]*(N-1);a=(a+[ZERO_L]*N)[:N]
    while e:
        if e&1:r=lpoly_mul(r,a,N)
        a=lpoly_mul(a,a,N);e//=2
    return r

def sha(data:bytes):return hashlib.sha256(data).hexdigest()
def is_prime(n:int):
    if n<2:return False
    if n%2==0:return n==2
    d=3
    while d*d<=n:
        if n%d==0:return False
        d+=2
    return True

ROOT=Path(__file__).resolve().parent
q0=17**16
q=17**48
MODPOLY=[3]+[0]*7+[1]+[0]*7+[1]
BETA=list(fc(2));BETA[1]=1;BETA=tuple(BETA)
ETA=[0]*DEG;ETA[9]=6;ETA=tuple(ETA)
U=(ZERO_F,ONE_F,ZERO_F)


def main():
    # 1. Base field and extension checks.
    x=[0,1]
    assert ppowmod(x,17**16,MODPOLY)==x
    assert pgcd(psub(ppowmod(x,17**8,MODPOLY),x),MODPOLY)==[1]
    assert fpow(ETA,256)==ONE_F and fpow(ETA,128)==fc(-1) and fpow(ETA,16)==fc(3)
    assert pow(17,16,256)==1 and all(pow(17,d,256)!=1 for d in (1,2,4,8))
    nc=fpow(BETA,(q0-1)//3)
    expected=list(ZERO_F);expected[0]=2;expected[8]=5
    assert nc==tuple(expected) and nc!=ONE_F
    assert lpow(U,3)==lfrom(BETA)

    ep=[ONE_F]
    for _ in range(1,256):ep.append(fmul(ep[-1],ETA))
    assert len(set(ep))==256 and BETA not in ep

    # 2. Canonical packet accounting and 336 U-slot factors.
    ESET=((0,1,2,3,5,11,12,13),(0,1,2,3,4,8,9,14),(0,1,2,4,5,7,11,14))
    SCOLOR=(15,9,12)
    options=[(ty,a,(SCOLOR[ty]+8*(a&1))%16) for ty in range(3) for a in range(16)]
    dp=[0]*16;dp[0]=1
    for _ in range(7):
        nd=[0]*16
        for r,cnt in enumerate(dp):
            for _,_,col in options:nd[(r+col)%16]+=cnt
        dp=nd
    packet_count=dp[4]
    assert packet_count==52747567104

    slot_blob=bytearray(b'RS-MCA-CYCLE86-U-SLOT-FACTORS-v1\0')
    G=[[None]*48 for _ in range(7)]
    U2=lmul(U,U)
    for t in range(1,8):
        for ty in range(3):
            for a in range(16):
                z=ONE_L
                for e0 in ESET[ty]:
                    b=(a+e0)&15
                    fac=lsub(U2,lfrom(ep[(2*t+16*b)&255]))
                    z=lmul(z,fac)
                k=16*ty+a;G[t-1][k]=z
                slot_blob.extend(bytes((t,ty+1,a)));slot_blob.extend(lencode(z))
    slot_sha=sha(bytes(slot_blob))
    assert slot_sha=='e64ab0c0e51c9f0487557916486a5fcb8360b8fb97de1000a6931afe5945851c'

    # 3. Explicit shortened 464-point domain, y=U and c=beta-U.
    c=lsub(lfrom(BETA),U)
    removed={8*a for a in range(1,25)}
    exponents=[e for e in range(256) if e not in removed]
    assert len(exponents)==232 and 1 in exponents and 0 in exponents
    first=[lfrom(ep[e]) for e in exponents]
    second=[ladd(c,lfrom(ep[e])) for e in exponents]
    assert len(set(first))==232 and len(set(second))==232
    assert set(first).isdisjoint(second)
    assert lfrom(BETA) not in first and lfrom(BETA) not in second
    domain_blob=bytearray(b'RS-MCA-CYCLE87-464-DOMAIN-v1\0')
    for block,pts in enumerate((first,second)):
        for e,z in zip(exponents,pts):
            domain_blob.extend(bytes((block,e)));domain_blob.extend(lencode(z))
    domain_sha=sha(bytes(domain_blob))

    # 4. Common six-jet and exact syndrome line.
    one_minus_t=[ONE_L,lfrom(fc(-1))]+[ZERO_L]*4
    one_minus_ct=[ONE_L,lneg(c)]+[ZERO_L]*4
    cp1=ladd(c,ONE_L)
    one_minus_cp1t=[ONE_L,lneg(cp1)]+[ZERO_L]*4
    K=lpoly_mul(lpoly_mul(one_minus_t,lpoly_pow(one_minus_ct,112)),one_minus_cp1t)
    H=[ZERO_L]*6;H[0]=ONE_L
    for n in range(1,6):
        z=ZERO_L
        for i in range(1,n+1):z=ladd(z,lmul(K[i],H[n-i]))
        H[n]=lneg(z)
    prod=lpoly_mul(K,H)
    assert prod[0]==ONE_L and all(x==ZERO_L for x in prod[1:])
    # Independent closed-form check from the algebraic derivation.
    cc=[ONE_L]
    for _ in range(5):cc.append(lmul(cc[-1],c))
    formulas=[
      ONE_L,
      ladd(lscale(c,-6),lfrom(fc(2))),
      ladd(ladd(lscale(cc[2],-2),lscale(c,6)),lfrom(fc(3))),
      ladd(ladd(ladd(lscale(cc[3],-3),lscale(cc[2],8)),lscale(c,2)),lfrom(fc(4))),
      ladd(ladd(ladd(ladd(lscale(cc[4],-2),lscale(cc[3],4)),lscale(cc[2],-3)),lscale(c,-1)),lfrom(fc(5))),
      ladd(ladd(ladd(lscale(cc[5],-6),lscale(cc[4],3)),lscale(c,-3)),lfrom(fc(6)))
    ]
    assert H==formulas
    u=[ZERO_L]*232;v=[ZERO_L]*232
    for i in range(6):u[225+i]=H[i]
    v[231]=ONE_L
    line_blob=bytearray(b'RS-MCA-CYCLE87-464-LINE-v1\0')
    line_blob.extend(lencode(c))
    for z in u:line_blob.extend(lencode(z))
    for z in v:line_blob.extend(lencode(z))
    line_sha=sha(bytes(line_blob))

    # 5. Projective quotient divisor and generated-log/census bridge.
    ps=(3,7,13,73,307,1321,72337,83233)
    assert all(is_prime(p) for p in ps)
    msmall=math.prod(ps)
    mfull=q0*q0+q0+1
    cofactor=48661191868691111041
    assert msmall==48661191882642625923 and msmall*cofactor==mfull
    logs_path=ROOT/'cycle87_projective_logs.txt'
    lines=logs_path.read_text().strip().splitlines()
    assert lines[0]==f'Msmall={msmall}'
    logs=[[int(x) for x in row.split(',')] for row in lines[1:]]
    assert len(logs)==7 and all(len(r)==48 for r in logs)
    assert all(0<=x<msmall for r in logs for x in r)
    src=(ROOT/'cycle87_u_projection_census_radix.cpp').read_text()
    arrays=[]
    for name in ('W_LO','W_HI'):
        m=re.search(r'static const u64 '+name+r'\[7\]\[48\]=\{(.*?)\n\};',src,re.S);assert m
        rows=re.findall(r'\{([^{}]*)\}',m.group(1));assert len(rows)==7
        arrays.append([[int(x) for x in re.findall(r'(\d+)ULL',row)] for row in rows])
    lo,hi=arrays
    embedded=[[(hi[t][k]<<64)|lo[t][k] for k in range(48)] for t in range(7)]
    assert embedded==logs

    # 6. Exhaustive census certificate and every part hash.
    cert=json.load(open(ROOT/'cycle87_u_projective_census_certificate.json'))
    cen=cert['census']
    assert cen=={'total_shards':6144,'completed_shards':6144,'compatible_tuples':52747567104,
                 'projected_distinct_keys':52747567062,'projected_offdiagonal_energy':84,
                 'projected_m_max':2,'double_projected_fibers':42}
    pos=0
    for part in cert['parts']:
        assert part['start']==pos
        p=ROOT/'census_parts'/part['file'];data=p.read_bytes()
        assert sha(data)==part['sha256']
        d=json.loads(data)
        assert d['shards']['start']==part['start'] and d['shards']['requested']==part['count']
        assert d['shards']['completed']==part['count'] and d['shards']['total']==6144
        assert d['compatible_tuples']==part['compatible_tuples']
        assert d['projected_distinct_keys']==part['distinct_keys']
        assert d['projected_offdiagonal_energy']==part['offdiagonal_energy']
        assert d['projected_m_max']==part['m_max']
        pos+=part['count']
    assert pos==6144
    # Three independent reducers agree on a collision-containing first-16-shard audit.
    audit=[]
    for name in ('hash_first16.json','comparison_sort_first16.json','radix_first16.json'):
        d=json.load(open(ROOT/'audits'/name))
        audit.append((d['compatible_tuples'],d['projected_distinct_keys'],d['projected_offdiagonal_energy'],d['projected_m_max']))
    assert audit[0]==audit[1]==audit[2]==(137384415,137384414,2,2)

    # 7. Code dimensions and exact official finite threshold.
    n,k,sigma,j=464,232,6,226
    assert n-k==232 and j==(n-k)-sigma and 2*k==n
    P=52747567104;N=52747567092
    NP=P*N
    slope_lb=NP//2
    target=q//2**128
    conservative=NP//8
    assert target==338617018271848945628
    assert conservative==347788229344751517696 and conservative>target
    assert slope_lb==1391152917379006070784 and slope_lb>target

    out={
      'certificate':'CYCLE87_EXPLICIT_U_SEPARATOR_AND_464_GRS_V1',
      'decision':'PASS',
      'field':{'q0':q0,'q_gen':q,'q_code':q,'q_line':q,'q_chal':q,
               'base_modulus':'X^16+X^8+3','extension_modulus':'U^3-(X+2)','separator':'U'},
      'packet':{'records':packet_count,'slot_factor_sha256':slot_sha},
      'projection':{'projective_quotient_order':mfull,'projection_modulus':msmall,
                    'projection_factors':list(ps),'projected_distinct_keys':52747567062,
                    'projected_offdiagonal_energy':84,'projected_m_max':2,'mu_proj_upper_bound':2},
      'grs':{'n':n,'k':k,'parity_rank':n-k,'sigma':sigma,'j':j,
             'domain_sha256':domain_sha,'line_sha256':line_sha,
             'translation_c_coefficients_hex':lhex(c),
             'h0_to_h5_coefficients_hex':[lhex(z) for z in H]},
      'frontier':{'P':P,'N':N,'support_pairs':NP,'same_slope_fiber_upper_bound':2,
                  'distinct_slope_lower_bound':slope_lb,'conservative_divide_by_8':conservative,
                  'target_floor_qline_over_2^128':target,
                  'conservative_margin':conservative-target},
      'audits':{'first16_reducer_consensus':list(audit[0])}}
    out_path=ROOT/'cycle87_master_materialization_certificate.json'
    if out_path.exists():
        old=json.load(open(out_path));assert old==out
    else:
        with open(out_path,'w') as f:json.dump(out,f,indent=2);f.write('\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__':
    main()
