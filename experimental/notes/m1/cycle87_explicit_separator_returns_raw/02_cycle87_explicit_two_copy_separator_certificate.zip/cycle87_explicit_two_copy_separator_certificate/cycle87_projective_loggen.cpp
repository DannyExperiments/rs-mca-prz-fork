#include <algorithm>
#include <array>
#include <boost/multiprecision/cpp_int.hpp>
#include <boost/multiprecision/cpp_dec_float.hpp>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>
using boost::multiprecision::uint256_t;
using u8=uint8_t; using u32=uint32_t; using u64=uint64_t; using u128=unsigned __int128;
static constexpr int P=17,D=16;
struct F { std::array<u8,D> a{}; bool operator==(F const&o)const{return a==o.a;} bool operator!=(F const&o)const{return a!=o.a;} };
static F fzero(){return F{};} static F fone(){F z;z.a[0]=1;return z;} static F fc(int c){F z;c%=P;if(c<0)c+=P;z.a[0]=(u8)c;return z;}
static F fadd(F x,F const&y){for(int i=0;i<D;i++)x.a[i]=(x.a[i]+y.a[i])%P;return x;}
static F fsub(F x,F const&y){for(int i=0;i<D;i++){int v=int(x.a[i])-int(y.a[i]);if(v<0)v+=P;x.a[i]=v;}return x;}
static F fneg(F x){for(auto &v:x.a)if(v)v=P-v;return x;}
static F fmul(F const&x,F const&y){int64_t w[31]{};for(int i=0;i<D;i++)if(x.a[i])for(int j=0;j<D;j++)if(y.a[j])w[i+j]+=int(x.a[i])*int(y.a[j]);for(int k=30;k>=16;k--){int64_t c=w[k]%P;if(c<0)c+=P;if(c){w[k-8]-=c;w[k-16]-=3*c;}}F z;for(int i=0;i<D;i++){int64_t v=w[i]%P;if(v<0)v+=P;z.a[i]=(u8)v;}return z;}
static F fpow(F b,uint256_t e){F r=fone();while(e){if((e&1)!=0)r=fmul(r,b);b=fmul(b,b);e>>=1;}return r;}
struct L { std::array<F,3> a{}; bool operator==(L const&o)const{return a==o.a;} bool operator!=(L const&o)const{return a!=o.a;} };
static F BETA;
static L lzero(){return L{};} static L lone(){L z;z.a[0]=fone();return z;} static L lfrom(F const&x){L z;z.a[0]=x;return z;} static L lu(){L z;z.a[1]=fone();return z;} static L lu2(){L z;z.a[2]=fone();return z;}
static L ladd(L x,L const&y){for(int i=0;i<3;i++)x.a[i]=fadd(x.a[i],y.a[i]);return x;}
static L lsub(L x,L const&y){for(int i=0;i<3;i++)x.a[i]=fsub(x.a[i],y.a[i]);return x;}
static L lmul(L const&x,L const&y){std::array<F,5>w{};for(int i=0;i<3;i++)for(int j=0;j<3;j++)w[i+j]=fadd(w[i+j],fmul(x.a[i],y.a[j]));w[1]=fadd(w[1],fmul(w[4],BETA));w[0]=fadd(w[0],fmul(w[3],BETA));L z;z.a[0]=w[0];z.a[1]=w[1];z.a[2]=w[2];return z;}
static L lpow(L b,uint256_t e){L r=lone();while(e){if((e&1)!=0)r=lmul(r,b);b=lmul(b,b);e>>=1;}return r;}
struct LHash{size_t operator()(L const&z)const noexcept{u64 h=1469598103934665603ULL;for(auto const&f:z.a)for(u8 x:f.a){h^=x;h*=1099511628211ULL;}return (size_t)h;}};
static std::string dec128(u128 x){if(!x)return"0";std::string s;while(x){s.push_back('0'+x%10);x/=10;}std::reverse(s.begin(),s.end());return s;}
static u64 invmod(u64 a,u64 m){int64_t t=0,nt=1,r=m,nr=a%m;while(nr){int64_t q=r/nr;auto tt=t-q*nt;t=nt;nt=tt;auto rr=r-q*nr;r=nr;nr=rr;}if(r!=1)throw std::runtime_error("invmod");if(t<0)t+=m;return (u64)t;}
struct BSGS {u64 p,n;L g,giant;std::unordered_map<L,u32,LHash>baby;BSGS(L const&gen,u64 ord):p(ord),g(gen){n=(u64)std::ceil(std::sqrt((long double)p));baby.reserve(n*2+10);L cur=lone();for(u64 j=0;j<n;j++){baby.emplace(cur,(u32)j);cur=lmul(cur,g);}giant=lpow(g,uint256_t(p-n%p));}
 u64 solve(L const&h)const{L cur=h;for(u64 i=0;i<=n;i++){auto it=baby.find(cur);if(it!=baby.end()){u64 x=i*n+it->second;if(x<p&&lpow(g,uint256_t(x))==h)return x;}cur=lmul(cur,giant);}throw std::runtime_error("no dlog");}};
static const int ESET[3][8]={{0,1,2,3,5,11,12,13},{0,1,2,3,4,8,9,14},{0,1,2,4,5,7,11,14}};
static const int SCOLOR[3]={15,9,12};
int main(){
 uint256_t q0=1;for(int i=0;i<16;i++)q0*=17;uint256_t M=q0*q0+q0+1;
 std::array<u64,8> ps={3,7,13,73,307,1321,72337,83233};u128 Msmall=1;for(auto p:ps)Msmall*=p;
 uint256_t prod=uint256_t(Msmall)*uint256_t("48661191868691111041");if(prod!=M)throw std::runtime_error("factorization");
 BETA=fc(2);BETA.a[1]=1;F eta;eta.a[9]=6;
 if(fpow(eta,uint256_t(256))!=fone()||fpow(eta,uint256_t(128))!=fc(-1)||fpow(eta,uint256_t(16))!=fc(3))throw std::runtime_error("eta");
 F nc=fpow(BETA,(q0-1)/3);std::cerr<<"noncube coeff0="<<int(nc.a[0])<<" coeff8="<<int(nc.a[8])<<"\n";
 std::array<F,256> ep;ep[0]=fone();for(int i=1;i<256;i++)ep[i]=fmul(ep[i-1],eta);
 std::array<std::array<L,48>,7> G;
 L U2=lu2();
 for(int t=1;t<=7;t++)for(int ty=0;ty<3;ty++)for(int a=0;a<16;a++){L z=lone();for(int j=0;j<8;j++){int b=(a+ESET[ty][j])&15;L fac=U2;fac.a[0]=fneg(ep[(2*t+16*b)&255]);z=lmul(z,fac);}G[t-1][ty*16+a]=z;}
 std::vector<L> gens;std::vector<BSGS> sol;gens.reserve(ps.size());sol.reserve(ps.size());
 for(u64 p:ps){uint256_t ex=(q0-1)*(M/uint256_t(p));L gp;u64 rank=0;for(rank=0;rank<100000;rank++){F f;u64 x=rank;for(int i=0;i<16;i++){f.a[i]=x%17;x/=17;}L cand=lu();cand.a[0]=f;gp=lpow(cand,ex);if(gp!=lone())break;}if(rank==100000)throw std::runtime_error("no gen");if(lpow(gp,uint256_t(p))!=lone())throw std::runtime_error("order");std::cerr<<"p="<<p<<" rank="<<rank<<"\n";gens.push_back(gp);sol.emplace_back(gp,p);}
 std::array<std::array<u128,48>,7> logs{};
 for(int t=0;t<7;t++)for(int k=0;k<48;k++){
   u128 x=0,mod=1;
   for(size_t ii=0;ii<ps.size();ii++){u64 p=ps[ii];uint256_t ex=(q0-1)*(M/uint256_t(p));L target=lpow(G[t][k],ex);u64 a=sol[ii].solve(target);u64 xm=(u64)(x%p);u64 mm=(u64)(mod%p);u64 delta=(a+p-xm)%p;u64 z=(u128(delta)*invmod(mm,p))%p;x+=mod*u128(z);mod*=p;}
   if(mod!=Msmall)throw std::runtime_error("crt mod");logs[t][k]=x;
 }
 // Verify all logs add under each component by exponentiation implicit; print C++ constants.
 std::cout<<"Msmall="<<dec128(Msmall)<<"\n";
 for(int t=0;t<7;t++){for(int k=0;k<48;k++){if(k)std::cout<<",";std::cout<<dec128(logs[t][k]);}std::cout<<"\n";}
 return 0;
}
