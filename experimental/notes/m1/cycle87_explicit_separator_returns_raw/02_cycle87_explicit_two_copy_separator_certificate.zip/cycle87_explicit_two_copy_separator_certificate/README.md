# Cycle87 explicit U-separator replay bundle

This bundle closes the active checker wall
`V-CYCLE86-U-PROJECTIVE-MMAX8-CENSUS` and materializes the shortened
`(464,232,6,226)` one-line GRS construction.

## Fast verification

```bash
./REPRODUCE_CYCLE87.sh
```

This recompiles the exact projective-log producer, checks its output against
the checked-in 336-factor log table, verifies the collision-containing
first-16-shard census, recomputes the symbolic field/domain/line certificate,
and validates all 25 stored census parts and hashes.

## Full census replay

```bash
./REPRODUCE_CYCLE87.sh --full
```

This re-enumerates all 52,747,567,104 admissible packet tuples in 6144 exact
cyclic shards, aggregates them, and checks the final census fields. Runtime is
hardware-dependent; the supplied run used exact integer/finite-field
arithmetic and no probabilistic verdicts.

## Main outputs

* `CYCLE87_EXPLICIT_TWO_COPY_SEPARATOR_PROOF.md` — theorem and proof.
* `cycle87_master_materialization_certificate.json` — fast symbolic and ledger
  certificate.
* `cycle87_u_projective_census_certificate.json` — exhaustive census manifest.
* `cycle87_projective_loggen.cpp` — exact finite-field/projective character
  producer.
* `cycle87_u_projection_census_radix.cpp` — exhaustive MITM + exact radix
  run-length reducer.
* `verify_cycle87_symbolic.py` — independent standard-library verifier.
* `census_parts/` — complete contiguous 6144-shard certificate outputs.

The result is an official-rate finite MCA counterpacket under the banked
Cycle85/Cycle86 profile. It is not, by itself, the full proximity-prize theorem.
