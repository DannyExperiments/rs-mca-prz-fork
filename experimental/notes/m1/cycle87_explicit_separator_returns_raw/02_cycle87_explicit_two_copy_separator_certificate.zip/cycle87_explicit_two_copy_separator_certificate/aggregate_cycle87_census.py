#!/usr/bin/env python3
import argparse, hashlib, json, os

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--parts',default='census_parts')
    ap.add_argument('--output',default='cycle87_u_projective_census_certificate.rebuilt.json')
    args=ap.parse_args()
    paths=[]
    for name in os.listdir(args.parts):
        if name.endswith('.json'):
            p=os.path.join(args.parts,name)
            try:d=json.load(open(p))
            except Exception:continue
            if 'shards' in d:paths.append((d['shards']['start'],p,d))
    paths.sort()
    pos=0; P=U=D=0; M=0; parts=[]
    for start,p,d in paths:
        sh=d['shards']; count=sh['requested']
        assert start==pos, f'gap/overlap: expected {pos}, got {start}'
        assert sh['total']==6144 and sh['completed']==count
        assert d['decision']=='PROJECTED_MMAX_LE_8' and d['hit_value'] is None
        P+=d['compatible_tuples']; U+=d['projected_distinct_keys']
        D+=d['projected_offdiagonal_energy']; M=max(M,d['projected_m_max'])
        parts.append({
          'start':start,'count':count,'file':os.path.basename(p),
          'sha256':hashlib.sha256(open(p,'rb').read()).hexdigest(),
          'compatible_tuples':d['compatible_tuples'],
          'distinct_keys':d['projected_distinct_keys'],
          'offdiagonal_energy':d['projected_offdiagonal_energy'],
          'm_max':d['projected_m_max']})
        pos+=count
    assert pos==6144
    assert P==52747567104
    assert M<=2
    assert D==2*(P-U), 'with max<=2, D must equal twice number of double fibers'
    out={
      'certificate':'CYCLE87_U_PROJECTIVE_PROJECTION_CENSUS_V1',
      'decision':'U_PROJECTIVE_MULTIPLICITY_LE_2',
      'separator':{'base_field':'F_17[X]/(X^16+X^8+3)','extension':'L=F0[U]/(U^3-(X+2))','y':'U'},
      'projection':{'quotient':'L^x/F0^x','cyclic_projection_modulus':'48661191882642625923','factorization':[3,7,13,73,307,1321,72337,83233]},
      'census':{'total_shards':6144,'completed_shards':6144,'compatible_tuples':P,'projected_distinct_keys':U,'projected_offdiagonal_energy':D,'projected_m_max':M,'double_projected_fibers':P-U},
      'implication':{'mu_proj_y_upper_bound':M,'required_upper_bound':8,'pass':M<=8},
      'parts':parts}
    with open(args.output,'w') as f:json.dump(out,f,indent=2);f.write('\n')
    print(json.dumps(out['census'],sort_keys=True))
if __name__=='__main__':main()
