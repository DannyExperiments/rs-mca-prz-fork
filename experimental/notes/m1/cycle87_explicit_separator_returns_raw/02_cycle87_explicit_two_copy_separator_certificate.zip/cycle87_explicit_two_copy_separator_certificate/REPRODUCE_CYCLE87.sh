#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")" && pwd)
cd "$ROOT"
CXX=${CXX:-g++}
CXXFLAGS=${CXXFLAGS:--O3 -std=c++17 -pthread}
TMP=${TMPDIR:-/tmp}/cycle87_u_replay_$$
mkdir -p "$TMP"
trap 'rm -rf "$TMP"' EXIT

echo '[1/5] compile and regenerate exact projective logs'
$CXX $CXXFLAGS cycle87_projective_loggen.cpp -o "$TMP/loggen"
"$TMP/loggen" > "$TMP/projective_logs.txt" 2> "$TMP/loggen.stderr"
cmp cycle87_projective_logs.txt "$TMP/projective_logs.txt"

echo '[2/5] compile exact census reducer and replay collision-containing first 16 shards'
$CXX $CXXFLAGS cycle87_u_projection_census_radix.cpp -o "$TMP/census"
"$TMP/census" 4 0 16 6144 > "$TMP/first16.json" 2> "$TMP/first16.stderr"
python3 - "$TMP/first16.json" <<'PY'
import json,sys
d=json.load(open(sys.argv[1]))
got=(d['compatible_tuples'],d['projected_distinct_keys'],d['projected_offdiagonal_energy'],d['projected_m_max'])
assert got==(137384415,137384414,2,2),got
print('first16=',got)
PY

echo '[3/5] rebuild stored exhaustive census manifest'
python3 aggregate_cycle87_census.py --parts census_parts --output "$TMP/stored_census.json"
cmp cycle87_u_projective_census_certificate.json "$TMP/stored_census.json"

echo '[4/5] verify field, slot table, domain, line, projection bridge, dimensions, and threshold'
python3 verify_cycle87_symbolic.py > "$TMP/symbolic.json"

echo '[5/5] verify bundle hashes'
sha256sum -c SHA256SUMS.txt

if [[ "${1:-}" == "--full" ]]; then
  echo '[full] replaying all 6144 shards in 24 chunks of 256'
  mkdir -p "$TMP/replay_parts"
  for start in $(seq 0 256 5888); do
    last=$((start+255))
    out=$(printf '%s/replay_parts/c87_radix_%04d_%04d.json' "$TMP" "$start" "$last")
    echo "  shards $start..$last"
    "$TMP/census" "${CYCLE87_THREADS:-12}" "$start" 256 6144 > "$out" 2> "${out%.json}.log"
  done
  python3 aggregate_cycle87_census.py --parts "$TMP/replay_parts" --output "$TMP/replayed_census.json"
  python3 - "$TMP/replayed_census.json" <<'PY'
import json,sys
new=json.load(open(sys.argv[1]));old=json.load(open('cycle87_u_projective_census_certificate.json'))
assert new['census']==old['census'],(new['census'],old['census'])
assert new['implication']==old['implication']
assert new['projection']==old['projection']
print('full census=',new['census'])
PY
fi

echo 'PASS: Cycle87 explicit U-separator and 464-point one-line GRS certificate'
