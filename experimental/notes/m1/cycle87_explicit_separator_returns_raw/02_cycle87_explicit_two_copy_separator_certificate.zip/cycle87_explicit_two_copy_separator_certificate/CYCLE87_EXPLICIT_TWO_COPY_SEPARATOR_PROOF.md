# Cycle 87 explicit two-copy separator and one-line GRS certificate

## Status

**PROOF of the active finite wall**

```text
L-CYCLE86-EXPLICIT-TWO-COPY-SEPARATOR-CERTIFICATE
V-CYCLE86-U-PROJECTIVE-MMAX8-CENSUS
```

The concrete separator is `y = U` in

\[
F_0=\mathbf F_{17}[X]/(X^{16}+X^8+3),\qquad
L=F_0[U]/(U^3-(X+2)).
\]

The exact certificate proves the stronger bound

\[
\mu_{\rm proj}(U)\le 2<8.
\]

It also materializes one `[464,232]` GRS code, one affine syndrome line, and
all two-copy support incidences. This closes the active finite/model wall and
produces an official-rate MCA fail row under the banked Cycle85/Cycle86 profile.
It does not by itself prove the full proximity-prize theorem or a scalar-list
statement.

## 1. Imported banked data

Put

\[
\eta=6X^9,\qquad D=\langle\eta\rangle,\qquad |D|=256,
\qquad \beta=X+2.
\]

The banked Cycle84 packet \(\mathcal P_0\) consists of \(113\)-subsets of
\(D\), has

\[
P:=|\mathcal P_0|=52,747,567,104,
\]

and satisfies, for every \(T\in\mathcal P_0\),

\[
J_T(t):=\prod_{x\in T}(1-xt)\equiv1-t\pmod {t^6}.
\]

Writing

\[
\rho(T)=P_T(\beta),\qquad P_T(Y)=\prod_{x\in T}(Y-x),
\]

the banked product census gives

\[
|\Omega|=|\{\rho(T):T\in\mathcal P_0\}|=N=52,747,567,092.
\]

Every packet support has the explicit form

\[
T=\{1\}\cup\bigcup_{t=1}^7
\{\pm\eta^{t+8b}:b\in a_t+E_{i_t}\pmod {16}\},
\]

where

\[
\begin{aligned}
E_1&=\{0,1,2,3,5,11,12,13\},\\
E_2&=\{0,1,2,3,4,8,9,14\},\\
E_3&=\{0,1,2,4,5,7,11,14\},
\end{aligned}
\]

and the seven option colors sum to \(4\pmod {16}\). Thus all supports avoid
\(\langle\eta^8\rangle\setminus\{1\}\).

## 2. One-copy Role05 parity-check realization

For \(x\in D\), define

\[
h_x^{(1)}=(1,x,\ldots,x^{117},(\beta-x)^{-1})^T\in F_0^{119}.
\]

Multiplying the \(x\)-column by \(\beta-x\) changes the row-polynomial basis
to

\[
1,(\beta-Y),(\beta-Y)Y,\ldots,(\beta-Y)Y^{117}.
\]

These are a basis of \(F_0[Y]_{\le118}\): if
\(a+(\beta-Y)Q(Y)=0\), evaluation at \(Y=\beta\) gives \(a=0\), then
\(Q=0\). Hence the matrix is row- and nonzero-column-equivalent to a
119-row Vandermonde parity-check matrix, so it defines a `[256,137]` GRS code.

For \(T\in\mathcal P_0\), put \(a_x=P_T'(x)^{-1}\). Partial fractions give

\[
\sum_{x\in T}a_xx^m=
\begin{cases}
0,&0\le m\le111,\\
h_{m-112}(T),&m\ge112,
\end{cases}
\]

where \(\sum h_r(T)t^r=J_T(t)^{-1}\). Since
\(J_T(t)^{-1}\equiv1+t+\cdots+t^5\pmod{t^6}\), the first 118 syndrome
coordinates are the common vector

\[
s_1=(0^{112},1,1,1,1,1,1).
\]

Also

\[
\sum_{x\in T}\frac{a_x}{\beta-x}=\frac1{P_T(\beta)}=\rho(T)^{-1}.
\]

Thus the one-copy line is

\[
\ell_1(z)=(s_1,z),
\]

and it meets the span of \(T\) at \(z=\rho(T)^{-1}\). Replacing the line
direction by its negative gives the Cycle85 gauge \(-\rho(T)^{-1}\).

## 3. The explicit 464-point two-copy domain

The base modulus is irreducible, \(\eta\) has exact order \(256\), and

\[
\beta^{(17^{16}-1)/3}=2+5X^8\ne1.
\]

Therefore \(U^3-\beta\) is irreducible over \(F_0\), and
\(L\cong\mathbf F_{17^{48}}\).

Take

\[
y=U,\qquad c=\beta-U,
\]

and delete the 24 universally unused points

\[
Z=\{\eta^{8a}:1\le a\le24\},\qquad A=D\setminus Z,
\qquad |A|=232.
\]

Define the ordered domain

\[
\mathcal D=A\sqcup(c+A).
\]

The two blocks are disjoint because \(c\notin F_0\). Moreover \(\beta\) is
in neither block. Since \(A\) contains \(\eta\) and \(\operatorname{ord}_{256}(17)=16\), it generates \(F_0\); and
from \(\eta,c+\eta\in\mathcal D\) one recovers \(c\), hence
\(U=\beta-c\). Thus the domain generates all of \(L\).

For \(T_1,T_2\in\mathcal P_0\), define

\[
\Psi(T_1,T_2)=T_1\sqcup(c+T_2).
\]

This map is injective and every support has size \(226\).

## 4. One GRS code and one syndrome line

For every \(x\in\mathcal D\), define

\[
h_x=(1,x,\ldots,x^{230},(\beta-x)^{-1})^T\in L^{232}.
\]

Exactly as above, after multiplying the \(x\)-column by \(\beta-x\), the
rows are evaluations of

\[
1,(\beta-Y),(\beta-Y)Y,\ldots,(\beta-Y)Y^{230},
\]

which form a basis of \(L[Y]_{\le231}\). Hence this is one parity-check
matrix for a single

\[
[464,232]\ \mathrm{GRS}_L
\]

code. In particular

\[
(n,k,\sigma,j)=(464,232,6,226),\qquad j=(n-k)-\sigma.
\]

Translation of the banked jet gives

\[
J_{c+T}(t)=(1-ct)^{113}J_T\!\left(\frac{t}{1-ct}\right)
\equiv(1-ct)^{112}(1-(c+1)t)\pmod{t^6}.
\]

Therefore every combined support has the same jet

\[
K_c(t):=(1-t)(1-ct)^{112}(1-(c+1)t)\pmod{t^6}.
\]

Write

\[
K_c(t)^{-1}\equiv h_0+h_1t+\cdots+h_5t^5\pmod{t^6}.
\]

In characteristic 17 these coefficients are

\[
\begin{aligned}
h_0&=1,\\
h_1&=2-6c,\\
h_2&=3+6c-2c^2,\\
h_3&=4+2c+8c^2-3c^3,\\
h_4&=5-c-3c^2+4c^3-2c^4,\\
h_5&=6-3c+3c^4-6c^5.
\end{aligned}
\]

Set

\[
s_c=(0^{225},h_0,h_1,h_2,h_3,h_4,h_5)\in L^{231},
\quad u=(s_c,0),\quad v=e_{232},
\]

and define the single affine syndrome line

\[
\ell(z)=u+zv=(s_c,z).
\]

For \(S=\Psi(T_1,T_2)\), put \(a_x=P_S'(x)^{-1}\). The same moment and
partial-fraction identities give

\[
\sum_{x\in S}a_x(1,x,\ldots,x^{230})^T=s_c
\]

and

\[
\sum_{x\in S}\frac{a_x}{\beta-x}=\frac1{P_S(\beta)}.
\]

Since

\[
P_S(\beta)=P_{T_1}(\beta)P_{T_2}(\beta-c)
=\rho(T_1)P_{T_2}(U),
\]

the exact slope is

\[
z(T_1,T_2)=\frac1{\rho(T_1)P_{T_2}(U)}.
\]

This is the required reciprocal-product formula. A global sign or any common
affine reparameterization of \(z\) is bijective and changes no count.

## 5. Transversality and full-coordinate support

Every \(a_x=P_S'(x)^{-1}\) is nonzero, so the representation uses every
coordinate of \(S\).

If \(v\in\operatorname{span}\{h_x:x\in S\}\), projection to the first 231
coordinates would give a linear dependence among the 226 distinct columns

\[
(1,x,\ldots,x^{230})^T,
\]

but a 231-by-226 Vandermonde matrix has full column rank. Hence

\[
v\notin\operatorname{span}H_S.
\]

Thus no selected span contains the affine line; every displayed incidence is
transverse, and each support span meets the line in at most one parameter.

## 6. Concrete projective separator certificate

The projective quotient

\[
Q=L^\times/F_0^\times
\]

is cyclic of order

\[
M=17^{32}+17^{16}+1
=2,367,911,594,760,467,245,892,767,489,196,618,115,843.
\]

Let

\[
M_0=3\cdot7\cdot13\cdot73\cdot307\cdot1321\cdot72337\cdot83233
=48,661,191,882,642,625,923.
\]

The exact factorization check is

\[
M=M_0\cdot48,661,191,868,691,111,041.
\]

For every prime \(p\mid M_0\), define

\[
\chi_p([z])=z^{(17^{48}-1)/p}\in\mu_p(L).
\]

This is well-defined on \(Q\), because the exponent is a multiple of
\(17^{16}-1\), so it kills \(F_0^\times\). Choosing a generator of each
\(\mu_p\), taking discrete logs, and combining by CRT gives a homomorphism

\[
\chi:Q\longrightarrow\mathbf Z/M_0\mathbf Z.
\]

Crucially, \(\chi\) is allowed to have a kernel: if two elements have the
same projective class, then they have the same \(\chi\)-key. Consequently

\[
\mu_{\rm proj}(U)\le
\max_r\#\{T\in\mathcal P_0:\chi(P_T(U))=r\}.
\]

For an option \((t,i,a)\), put

\[
G_{t,i,a}=\prod_{b\in a+E_i}(U^2-\eta^{2t+16b}).
\]

The packet formula gives the exact common-factor identity

\[
P_T(U)=(U-1)\prod_{t=1}^7G_{t,i_t,a_t}.
\]

The common factor \(U-1\) has no effect on fiber multiplicities. The producer
reconstructs all 336 factors. Its canonical table hash is

```text
e64ab0c0e51c9f0487557916486a5fcb8360b8fb97de1000a6931afe5945851c
```

The exhaustive 6144-shard census enumerated all
\(52,747,567,104\) admissible tuples and returned

```text
records                         52,747,567,104
projected distinct keys         52,747,567,062
ordered off-diagonal energy     84
projected maximum multiplicity  2
```

Thus there are 42 double projected fibers and no fiber of size at least 3.
Since projective fibers refine these projected fibers,

\[
\boxed{\mu_{\rm proj}(U)\le2.}
\]

This is stronger than the required \(\mu_{\rm proj}(U)\le8\).

## 7. Same-slope bound and official finite target

Choose one support \(T_a\) for each \(a\in\Omega\), and pair it with every
\(T\in\mathcal P_0\). This gives exactly

\[
NP=2,782,305,834,758,012,141,568
\]

supports. If two slopes agree, then

\[
aP_T(U)=a'P_{T'}(U),
\]

so \([P_T(U)]=[P_{T'}(U)]\) in \(Q\). For a fixed slope and a fixed second
support \(T\), the scalar \(a\) is uniquely determined. Hence every slope
fiber has size at most \(\mu_{\rm proj}(U)\le2\), and

\[
M_C(6)\ge\frac{NP}{2}
=1,391,152,917,379,006,070,784.
\]

Even the deliberately weaker divide-by-8 count is

\[
\frac{NP}{8}=347,788,229,344,751,517,696.
\]

The domain generates \(L\), so the natural ledger assignment is

\[
q_{\rm gen}=q_{\rm code}=q_{\rm line}=q_{\rm chal}=17^{48};
\]

only \(q_{\rm line}\) enters the denominator. The exact target is

\[
\left\lfloor\frac{17^{48}}{2^{128}}\right\rfloor
=338,617,018,271,848,945,628.
\]

Therefore the conservative count already clears the target by

\[
9,171,211,072,902,572,068.
\]

## 8. Scope and first external dependency

What is proved:

* the explicit separator \(y=U\) has \(\mu_{\rm proj}(U)\le2\);
* the shortened package is one `[464,232]` GRS code and one affine syndrome
  line;
* all selected 226-support incidences are full-coordinate and transverse;
* the reciprocal-product slope packet clears the official `2^-128` finite
  threshold.

What is not proved:

* a scalar-list numerator theorem;
* that this finite MCA fail row alone settles the full proximity prize;
* any theorem outside the banked Cycle84 packet/common-jet and Cycle85 MCA
  interpretation.

The first imported line on which the proof depends is the banked assertion
that the Cycle84 family is exactly the stated color-compatible packet and has
\(J_T(t)\equiv1-t\pmod{t^6}\), together with its exact \(\rho(\beta)\)
occupancy. The slot-factor SHA, packet record count, and all later algebra are
recomputed by the replay artifact.
