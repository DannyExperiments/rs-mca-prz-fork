#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
THREADS="${THREADS:-4}"
SHARDS="${SHARDS:-1536}"

python3 cycle87_setup_verifier.py > replay_setup.log

g++ -O3 -std=c++17 -pthread cycle87_u_smooth_census.cpp -o cycle87_u_smooth_census.replay
/usr/bin/time -v ./cycle87_u_smooth_census.replay "$SHARDS" "$THREADS" cycle87_u_smooth_census_replay.json \
  > replay_census.stdout 2> replay_census.stderr

g++ -O3 -std=c++17 cycle87_464_materializer.cpp -o cycle87_464_materializer.replay
./cycle87_464_materializer.replay "$ROOT" > replay_materializer.log
python3 cycle87_verify_464_artifacts.py > replay_grs_verifier.log
python3 cycle87_verify_master.py --census cycle87_u_smooth_census_replay.json > replay_master_verifier.json
cat replay_master_verifier.json
