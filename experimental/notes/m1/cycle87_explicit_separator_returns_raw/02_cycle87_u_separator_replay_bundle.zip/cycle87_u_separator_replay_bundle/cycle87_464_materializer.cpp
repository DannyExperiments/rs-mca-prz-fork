#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <unordered_set>
#include <vector>
#include <boost/multiprecision/cpp_int.hpp>
using boost::multiprecision::cpp_int; using u8=uint8_t; using u32=uint32_t;
static constexpr int P=17,D=16;
struct F{std::array<u8,D>a{};bool operator==(const F&o)const noexcept{return a==o.a;} bool operator!=(const F&o)const noexcept{return !(*this==o);}};
static F zf(){return F{};} static F of(){F x;x.a[0]=1;return x;} static F sf(int c){F x;c%=P;if(c<0)c+=P;x.a[0]=c;return x;}
static F addf(const F&x,const F&y){F z;for(int i=0;i<D;i++)z.a[i]=(x.a[i]+y.a[i])%P;return z;} static F negf(const F&x){F z;for(int i=0;i<D;i++)z.a[i]=x.a[i]?P-x.a[i]:0;return z;} static F subf(const F&x,const F&y){return addf(x,negf(y));}
static F mulf(const F&x,const F&y){int w[31]{};for(int i=0;i<D;i++)if(x.a[i])for(int j=0;j<D;j++)if(y.a[j])w[i+j]+=x.a[i]*y.a[j];for(int k=30;k>=16;k--){int c=w[k]%P;if(c<0)c+=P;if(c){w[k-8]-=c;w[k-16]-=3*c;}}F z;for(int i=0;i<D;i++){int v=w[i]%P;if(v<0)v+=P;z.a[i]=v;}return z;}
static F BETA;
struct L{std::array<F,3>c{};bool operator==(const L&o)const noexcept{return c==o.c;} bool operator!=(const L&o)const noexcept{return !(*this==o);}};
static L zl(){return L{};}static L ol(){L x;x.c[0]=of();return x;}static L emb(const F&x){L z;z.c[0]=x;return z;}static L addl(const L&x,const L&y){L z;for(int i=0;i<3;i++)z.c[i]=addf(x.c[i],y.c[i]);return z;}static L negl(const L&x){L z;for(int i=0;i<3;i++)z.c[i]=negf(x.c[i]);return z;}static L subl(const L&x,const L&y){return addl(x,negl(y));}
static L mull(const L&a,const L&b){L z;z.c[0]=addf(mulf(a.c[0],b.c[0]),mulf(BETA,addf(mulf(a.c[1],b.c[2]),mulf(a.c[2],b.c[1]))));z.c[1]=addf(addf(mulf(a.c[0],b.c[1]),mulf(a.c[1],b.c[0])),mulf(BETA,mulf(a.c[2],b.c[2])));z.c[2]=addf(addf(mulf(a.c[0],b.c[2]),mulf(a.c[1],b.c[1])),mulf(a.c[2],b.c[0]));return z;}
static L powl(L b,cpp_int e){L r=ol();while(e>0){if((e&1)!=0)r=mull(r,b);b=mull(b,b);e>>=1;}return r;}
struct LH{size_t operator()(const L&x)const noexcept{uint64_t h=1469598103934665603ULL;for(auto&f:x.c)for(u8 v:f.a){h^=v;h*=1099511628211ULL;}return h;}};
static void write32(std::ofstream&o,u32 x){u8 b[4]={(u8)(x>>24),(u8)(x>>16),(u8)(x>>8),(u8)x};o.write((char*)b,4);}static void writeL(std::ofstream&o,const L&x){for(auto&f:x.c)o.write((char*)f.a.data(),16);}static cpp_int ipow(cpp_int a,int e){cpp_int r=1;while(e--){r*=a;}return r;}
using Poly=std::array<L,6>;
static Poly pmul(const Poly&a,const Poly&b){Poly c{};for(int i=0;i<6;i++)for(int j=0;i+j<6;j++)c[i+j]=addl(c[i+j],mull(a[i],b[j]));return c;}
static Poly ppow(Poly b,int e){Poly r{};r[0]=ol();while(e){if(e&1)r=pmul(r,b);b=pmul(b,b);e>>=1;}return r;}
int main(int argc,char**argv){
 try{
  std::string outdir=argc>1?argv[1]:"."; if(!outdir.empty()&&outdir.back()!='/')outdir.push_back('/');
  BETA=zf();BETA.a[0]=2;BETA.a[1]=1;F eta=zf();eta.a[9]=6;L U=zl();U.c[1]=of();L c=subl(emb(BETA),U);
  std::array<F,256> ep;ep[0]=of();for(int i=1;i<256;i++)ep[i]=mulf(ep[i-1],eta);
  std::vector<int> exps;for(int e=0;e<256;e++){bool del=(e>=8&&e<=192&&e%8==0);if(!del)exps.push_back(e);}if(exps.size()!=232)throw std::runtime_error("bad Dminus size");
  std::vector<L> dom;dom.reserve(464);for(int e:exps)dom.push_back(emb(ep[e]));for(int e:exps)dom.push_back(addl(c,emb(ep[e])));
  std::unordered_set<L,LH> seen;seen.reserve(700);for(auto&x:dom)if(!seen.insert(x).second)throw std::runtime_error("duplicate domain point");if(seen.count(emb(BETA)))throw std::runtime_error("beta in domain");
  {std::ofstream o(outdir+"cycle87_domain464.bin",std::ios::binary);std::string h="RS-MCA-CYCLE87-DOMAIN-464-v1";o.write(h.data(),h.size());o.put('\0');write32(o,464);for(auto&x:dom)writeL(o,x);}
  cpp_int q=1;for(int i=0;i<16;i++)q*=17;cpp_int q3=q*q*q, invexp=q3-2;
  {std::ofstream o(outdir+"cycle87_grs_H_232x464.bin",std::ios::binary);std::string h="RS-MCA-CYCLE87-GRS-H-232x464-v1";o.write(h.data(),h.size());o.put('\0');write32(o,232);write32(o,464);for(auto&x:dom){L pw=ol();for(int m=0;m<=230;m++){writeL(o,pw);pw=mull(pw,x);}L den=subl(emb(BETA),x);L iv=powl(den,invexp);if(mull(den,iv)!=ol())throw std::runtime_error("inverse failure");writeL(o,iv);}}
  // Common locator jet A(t)=(1-t)(1-ct)^112(1-(c+1)t), then H=A^{-1} mod t^6.
  Poly p1{};p1[0]=ol();p1[1]=negl(ol());Poly pc{};pc[0]=ol();pc[1]=negl(c);Poly pc1{};pc1[0]=ol();pc1[1]=negl(addl(c,ol()));Poly A=pmul(pmul(p1,ppow(pc,112)),pc1);Poly H{};H[0]=ol();for(int n=1;n<6;n++){L s=zl();for(int i=1;i<=n;i++)s=addl(s,mull(A[i],H[n-i]));H[n]=negl(s);}if(A[0]!=ol())throw std::runtime_error("jet constant");
  std::vector<L> u(232,zl()),v(232,zl());for(int r=0;r<6;r++)u[225+r]=H[r];v[231]=ol();
  {std::ofstream o(outdir+"cycle87_line_464.bin",std::ios::binary);std::string h="RS-MCA-CYCLE87-LINE-464-v1";o.write(h.data(),h.size());o.put('\0');write32(o,232);for(auto&x:u)writeL(o,x);for(auto&x:v)writeL(o,x);}
  std::cout<<"domain=464 matrix=232x464 line_dim=232 materialized\n";
  return 0;
 }catch(const std::exception&e){std::cerr<<"ERROR: "<<e.what()<<"\n";return 2;}
}
