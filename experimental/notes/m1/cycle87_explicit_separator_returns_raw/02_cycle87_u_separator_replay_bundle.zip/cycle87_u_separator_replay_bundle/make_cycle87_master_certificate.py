#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, platform, subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent
FILES=[
 'CYCLE87_U_SEPARATOR_PROOF.md','cycle87_certificate_schema.json',
 'cycle87_setup_verifier.py','cycle87_setup_certificate.json','cycle87_u_slot_factors.bin',
 'cycle87_u_smooth_census.cpp','cycle87_u_smooth_census','cycle87_u_smooth_census_result.json','cycle87_u_smooth_census_run.log',
 'cycle87_464_materializer.cpp','cycle87_464_materializer','cycle87_domain464.bin','cycle87_grs_H_232x464.bin','cycle87_line_464.bin',
 'cycle87_verify_464_artifacts.py','cycle87_464_artifact_certificate.json',
 'cycle87_u_smooth_sort_audit.cpp','cycle87_u_smooth_sort_audit',
 'cycle87_u_smooth_sort_audit_result.json','cycle87_u_smooth_sort_audit_run.log',
 'cycle87_u_smooth_sort_audit_shard0_result.json','cycle87_u_smooth_sort_audit_shard0_run.log',
 'cycle87_u_separator_pass.json','cycle87_verify_master.py','make_cycle87_master_certificate.py',
 'REPLAY_CYCLE87_U_SEPARATOR.sh','README_CYCLE87_REPLAY.md',
 '20260621_cycle87_explicit_separator_context(1).zip',
]
def sha(p:Path)->str:
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
art={f:sha(ROOT/f) for f in FILES}
P=52_747_567_104; N=52_747_567_092; q=17**48; target=q//2**128
lower=P*N//2
cert={
 'schema':'cycle87.explicit-u-separator-master.v1',
 'decision':'CYCLE87_U_SEPARATOR_464_PROVED',
 'claim':'L-CYCLE86-EXPLICIT-TWO-COPY-SEPARATOR-CERTIFICATE',
 'confidence':'high',
 'dependencies':{
  'banked_cycle84':{'P':str(P),'N':str(N),'m_max_beta':2,'D':24},
  'banked_cycle85':['support_size_113','fixed_jet_J_T_eq_1_minus_t_mod_t6','rho_beta_transfer'],
  'input_context_zip_sha256':'34c118fc7a9de35c24ef7aa0365bc097f3dca0119075d5bc030b51a68e71dc3d'
 },
 'field':{
  'F0':'F_17[X]/(X^16+X^8+3)',
  'q0':'48661191875666868481',
  'L':'F0[U]/(U^3-(X+2))',
  'separator':'U',
  'q_L':str(q)
 },
 'projective_census':{
  'exact_equivalence':'[a]=[b] iff a^(q0-1)=b^(q0-1)',
  'smooth_order_M':'48661191882642625923',
  'smooth_cofactor_R':'48661191868691111041',
  'records':str(P),
  'smooth_occupancy':'52747567062',
  'smooth_histogram':{'multiplicity_1':'52747567020','multiplicity_2':42,'multiplicity_ge_3':0},
  'smooth_ordered_offdiagonal_energy':84,
  'smooth_max_multiplicity':2,
  'deduced_mu_proj_U_upper_bound':2
 },
 'grs_counterpacket':{
  'profile':{'t':1,'n':464,'k':232,'sigma':6,'j':226},
  'q_gen':str(q),'q_code':str(q),'q_line':str(q),'q_chal':str(q),
  'one_grs_code':True,'one_affine_syndrome_line':True,'transverse':True,
  'slope_formula':'z = common_nonzero_scalar/(rho_beta(T1)*P_T2(U))',
  'pair_numerator':str(P*N),
  'collision_divisor':2,
  'certified_distinct_slopes':str(lower),
  'T_line':str(target),
  'margin':str(lower-target)
 },
 'execution':{
  'census_shards':1536,'census_threads':4,
  'census_elapsed_seconds':940.485555567,
  'census_wall_wrapper':'15:40.50',
  'census_max_rss_kib':2299780,
  'census_exit_status':0,
  'platform':platform.platform(),
  'python':platform.python_version(),
 },
 'scope':{
  'finite_model_certificate':True,
  'one_copy_transfer':'banked_dependency',
  'official_two_copy_mca_counterpacket':True,
  'public_replay_artifact':True,
  'full_prize_theorem':False
 },
 'artifacts_sha256':art
}
out=ROOT/'cycle87_master_certificate.json'
out.write_text(json.dumps(cert,indent=2,sort_keys=True)+'\n')
print(json.dumps(cert,indent=2,sort_keys=True))
