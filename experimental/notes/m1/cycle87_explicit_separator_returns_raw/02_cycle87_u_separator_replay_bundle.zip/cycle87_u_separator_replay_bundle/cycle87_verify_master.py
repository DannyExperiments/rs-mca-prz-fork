#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def sha(p:Path)->str:
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()

def main()->None:
 ap=argparse.ArgumentParser()
 ap.add_argument('--census',default='cycle87_u_smooth_census_result.json')
 ap.add_argument('--skip-artifact-hashes',action='store_true')
 a=ap.parse_args()
 master=json.loads((ROOT/'cycle87_master_certificate.json').read_text())
 assert master['decision']=='CYCLE87_U_SEPARATOR_464_PROVED'
 if not a.skip_artifact_hashes:
  for name,want in master['artifacts_sha256'].items():
   p=ROOT/name
   assert p.is_file(),f'missing {name}'
   got=sha(p)
   assert got==want,f'hash mismatch {name}: {got} != {want}'
 pass_result=json.loads((ROOT/'cycle87_u_separator_pass.json').read_text())
 assert pass_result['decision']=='PASS'
 assert pass_result['claim']=='CYCLE87_U_PROJECTIVE_MMAX_LE_8'
 assert pass_result['smooth']['max_multiplicity']==2
 assert pass_result['deduced']['mu_proj_upper_bound']==2
 setup=json.loads((ROOT/'cycle87_setup_certificate.json').read_text())
 assert setup['decision']=='SETUP_VERIFIED'
 grs=json.loads((ROOT/'cycle87_464_artifact_certificate.json').read_text())
 assert grs['decision']=='GRS464_ARTIFACTS_VERIFIED'
 for fn,expected in [(
  'cycle87_u_smooth_sort_audit_shard0_result.json',(0,34348932,34348932,0,1)),
  ('cycle87_u_smooth_sort_audit_result.json',(1024,34345098,34345097,2,2))]:
  aud=json.loads((ROOT/fn).read_text())
  assert aud['decision']=='SORT_AUDIT_PASS'
  got=(aud['shard'],aud['pairs'],aud['unique'],aud['D_ordered_offdiagonal'],aud['max_multiplicity'])
  assert got==expected,(fn,got,expected)
 cp=Path(a.census)
 if not cp.is_absolute(): cp=ROOT/cp
 c=json.loads(cp.read_text())
 assert c['records']==52_747_567_104
 assert c['smooth_order_M']=='48661191882642625923'
 assert c['projected_occupancy']==52_747_567_062
 assert c['D_projected_offdiagonal_ordered']==84
 assert c['projected_max_multiplicity']==2
 assert c['coarse_hit_log'] is None
 P=52_747_567_104;N=52_747_567_092
 assert c['D_projected_offdiagonal_ordered']==2*(P-c['projected_occupancy'])
 n2=P-c['projected_occupancy'];n1=P-2*n2
 assert (n1,n2)==(52_747_567_020,42)
 q=17**48;T=q//2**128;lower=P*N//2
 assert T==338_617_018_271_848_945_628
 assert lower==1_391_152_917_379_006_070_784
 assert lower-T==1_052_535_899_107_157_125_156
 out={
  'schema':'cycle87.master-verification.v1',
  'decision':'CYCLE87_MASTER_CERTIFICATE_VERIFIED',
  'census_file':cp.name,
  'records':P,
  'smooth_histogram':{'m1':n1,'m2':n2,'m_ge_3':0},
  'mu_proj_U_upper_bound':2,
  'profile':{'t':1,'n':464,'k':232,'sigma':6,'j':226},
  'certified_distinct_slopes':str(lower),
  'T_line':str(T),
  'margin':str(lower-T),
 }
 print(json.dumps(out,indent=2,sort_keys=True))

if __name__=='__main__':main()
