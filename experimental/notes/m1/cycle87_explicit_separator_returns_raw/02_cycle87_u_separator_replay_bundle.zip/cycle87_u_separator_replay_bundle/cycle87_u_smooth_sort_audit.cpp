#define main cycle87_embedded_census_main
#include "cycle87_u_smooth_census.cpp"
#undef main

int main(int argc,char**argv){
 try{
  u32 sh=1024,NS=1536;if(argc>1)sh=std::stoul(argv[1]);if(argc>2)NS=std::stoul(argv[2]);
  std::string outpath=argc>3?argv[3]:"cycle87_u_smooth_sort_audit.json";
  if(sh>=NS)throw std::runtime_error("bad shard");
  auto st=std::chrono::steady_clock::now();setup_slots();build_mitm();
  u128 Lb=(MODM*sh)/NS,Ub=(MODM*(sh+1))/NS;
  if(Ub-Lb>(u128)UINT64_MAX)throw std::runtime_error("shard offset too wide");
  u64 np=0;
  for(const auto&a:A){const auto&v=B[(4-a.c)&15];u128 lo=Lb>=a.x?Lb-a.x:Lb+MODM-a.x,hi=Ub>=a.x?Ub-a.x:Ub+MODM-a.x;np+=range_count(v,lo,hi);}
  std::vector<u64> keys;keys.reserve(np);
  for(const auto&a:A){const auto&v=B[(4-a.c)&15];u128 lo=Lb>=a.x?Lb-a.x:Lb+MODM-a.x,hi=Ub>=a.x?Ub-a.x:Ub+MODM-a.x;
   auto run=[&](size_t p,size_t q){for(size_t j=p;j<q;j++){u128 sum=addm(a.x,v[j].x);if(sum<Lb||sum>=Ub)throw std::runtime_error("range translation error");keys.push_back((u64)(sum-Lb));}};
   if(lo<hi)run(lb(v,lo),lb(v,hi));else{run(lb(v,lo),v.size());run(0,lb(v,hi));}
  }
  if(keys.size()!=np)throw std::runtime_error("enumerated count mismatch");
  std::sort(keys.begin(),keys.end());
  u64 unique=0,D=0;u32 mmax=0;u64 doubles=0;size_t i=0;
  while(i<keys.size()){size_t j=i+1;while(j<keys.size()&&keys[j]==keys[i])j++;u64 m=j-i;unique++;D+=m*(m-1);if(m>mmax)mmax=m;if(m==2)doubles++;i=j;}
  double sec=std::chrono::duration<double>(std::chrono::steady_clock::now()-st).count();
  std::ofstream o(outpath);o<<"{\n  \"schema\": \"cycle87.u-smooth-sort-audit.v1\",\n  \"decision\": \"SORT_AUDIT_PASS\",\n  \"shard\": "<<sh<<",\n  \"shards_total\": "<<NS<<",\n  \"pairs\": "<<np<<",\n  \"unique\": "<<unique<<",\n  \"D_ordered_offdiagonal\": "<<D<<",\n  \"double_classes\": "<<doubles<<",\n  \"max_multiplicity\": "<<mmax<<",\n  \"elapsed_seconds\": "<<std::setprecision(15)<<sec<<"\n}\n";
  std::cout<<"shard="<<sh<<" pairs="<<np<<" unique="<<unique<<" D="<<D<<" max="<<mmax<<" doubles="<<doubles<<" sec="<<sec<<"\n";
  return 0;
 }catch(const std::exception&e){std::cerr<<"ERROR: "<<e.what()<<"\n";return 2;}
}
