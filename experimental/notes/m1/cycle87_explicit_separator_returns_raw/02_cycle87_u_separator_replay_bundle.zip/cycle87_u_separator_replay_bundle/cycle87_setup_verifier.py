#!/usr/bin/env python3
"""Exact standard-library verifier for the Cycle87 U-separator setup.

This verifies the finite-field models, support circuit, projective smooth quotient
factorization, and the canonical 336 raw slot-factor byte stream.  It performs no
probabilistic test and uses integer/polynomial arithmetic only.
"""
from __future__ import annotations

import hashlib
import json
import math
import struct
from pathlib import Path

P = 17
D = 16
Q0 = 17**16
Q_LINE = 17**48
T_LINE = Q_LINE // 2**128
QUOTIENT_ORDER = Q0*Q0 + Q0 + 1
R = 48_661_191_868_691_111_041
M = 48_661_191_882_642_625_923
M_FACTORS = (3, 7, 13, 73, 307, 1321, 72337, 83233)
ESETS = (
    (0, 1, 2, 3, 5, 11, 12, 13),
    (0, 1, 2, 3, 4, 8, 9, 14),
    (0, 1, 2, 4, 5, 7, 11, 14),
)
SCOLOR = (15, 9, 12)
EXPECTED_SLOT_SHA = "e64ab0c0e51c9f0487557916486a5fcb8360b8fb97de1000a6931afe5945851c"
ROOT = Path(__file__).resolve().parent

F = tuple[int, ...]
L = tuple[F, F, F]


def fzero() -> F:
    return (0,) * D


def fone() -> F:
    return (1,) + (0,) * (D - 1)


def fscalar(c: int) -> F:
    return (c % P,) + (0,) * (D - 1)


def fadd(a: F, b: F) -> F:
    return tuple((x + y) % P for x, y in zip(a, b))


def fneg(a: F) -> F:
    return tuple((-x) % P for x in a)


def fsub(a: F, b: F) -> F:
    return tuple((x - y) % P for x, y in zip(a, b))


def fmul(a: F, b: F) -> F:
    w = [0] * 31
    for i, x in enumerate(a):
        if x:
            for j, y in enumerate(b):
                if y:
                    w[i + j] += x * y
    # X^16 = -X^8 - 3.
    for k in range(30, 15, -1):
        c = w[k] % P
        if c:
            w[k - 8] -= c
            w[k - 16] -= 3 * c
    return tuple(x % P for x in w[:D])


def fpow(a: F, n: int) -> F:
    r = fone()
    while n:
        if n & 1:
            r = fmul(r, a)
        a = fmul(a, a)
        n >>= 1
    return r


BETA = (2, 1) + (0,) * 14


def lzero() -> L:
    z = fzero()
    return (z, z, z)


def lone() -> L:
    return (fone(), fzero(), fzero())


def lembed(a: F) -> L:
    return (a, fzero(), fzero())


def ladd(a: L, b: L) -> L:
    return tuple(fadd(x, y) for x, y in zip(a, b))  # type: ignore[return-value]


def lneg(a: L) -> L:
    return tuple(fneg(x) for x in a)  # type: ignore[return-value]


def lsub(a: L, b: L) -> L:
    return ladd(a, lneg(b))


def lmul(a: L, b: L) -> L:
    a0, a1, a2 = a
    b0, b1, b2 = b
    c0 = fadd(fmul(a0, b0), fmul(BETA, fadd(fmul(a1, b2), fmul(a2, b1))))
    c1 = fadd(fadd(fmul(a0, b1), fmul(a1, b0)), fmul(BETA, fmul(a2, b2)))
    c2 = fadd(fadd(fmul(a0, b2), fmul(a1, b1)), fmul(a2, b0))
    return c0, c1, c2


def lpow(a: L, n: int) -> L:
    r = lone()
    while n:
        if n & 1:
            r = lmul(r, a)
        a = lmul(a, a)
        n >>= 1
    return r


def encode_l(a: L) -> bytes:
    return bytes(v for coeff in a for v in coeff)


def color(option: int) -> int:
    i, a = divmod(option, 16)
    return (SCOLOR[i] + 8 * (a & 1)) & 15


def circular_convolution(a: list[int], b: list[int]) -> list[int]:
    return [sum(a[i] * b[(j - i) & 15] for i in range(16)) for j in range(16)]


def poly_mul_mod(a: list[int], b: list[int], mod: list[int]) -> list[int]:
    out = [0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            out[i + j] = (out[i + j] + x * y) % P
    n = len(mod) - 1
    for k in range(len(out) - 1, n - 1, -1):
        c = out[k] % P
        if c:
            for j in range(n):
                out[k - n + j] = (out[k - n + j] - c * mod[j]) % P
    out = out[:n]
    while len(out) > 1 and out[-1] == 0:
        out.pop()
    return out


def poly_pow_x_mod(exp: int, mod: list[int]) -> list[int]:
    r = [1]
    b = [0, 1]
    while exp:
        if exp & 1:
            r = poly_mul_mod(r, b, mod)
        b = poly_mul_mod(b, b, mod)
        exp >>= 1
    return r


def poly_trim(a: list[int]) -> list[int]:
    a = [x % P for x in a]
    while len(a) > 1 and a[-1] == 0:
        a.pop()
    return a


def poly_divmod(a: list[int], b: list[int]) -> tuple[list[int], list[int]]:
    a = poly_trim(a[:])
    b = poly_trim(b[:])
    if b == [0]:
        raise ZeroDivisionError
    if len(a) < len(b):
        return [0], a
    q = [0] * (len(a) - len(b) + 1)
    inv = pow(b[-1], P - 2, P)
    while len(a) >= len(b) and a != [0]:
        d = len(a) - len(b)
        c = a[-1] * inv % P
        q[d] = c
        for j, bj in enumerate(b):
            a[d + j] = (a[d + j] - c * bj) % P
        a = poly_trim(a)
    return poly_trim(q), a


def poly_gcd(a: list[int], b: list[int]) -> list[int]:
    a, b = poly_trim(a), poly_trim(b)
    while b != [0]:
        _, r = poly_divmod(a, b)
        a, b = b, r
    inv = pow(a[-1], P - 2, P)
    return [(x * inv) % P for x in a]


def main() -> None:
    # Base field irreducibility by Rabin's exact criterion for degree 16.
    f = [3] + [0] * 7 + [1] + [0] * 7 + [1]
    x_q8 = poly_pow_x_mod(17**8, f)
    x_q16 = poly_pow_x_mod(17**16, f)
    x_poly = [0, 1]
    diff8 = x_q8 + [0] * max(0, len(x_poly) - len(x_q8))
    if len(diff8) < 2:
        diff8 += [0] * (2 - len(diff8))
    diff8[1] = (diff8[1] - 1) % P
    gcd8 = poly_gcd(f, diff8)
    assert x_q16 == x_poly
    assert gcd8 == [1]
    # In fact x^(17^8) = -x, making the gcd check transparent.
    assert x_q8 == [0, 16]

    eta = (0,) * 9 + (6,) + (0,) * 6
    assert fpow(eta, 256) == fone()
    assert fpow(eta, 128) == fscalar(-1)
    assert all(fpow(eta, 256 // p) != fone() for p in (2,))
    ord_17_mod_256 = next(d for d in range(1, 33) if pow(17, d, 256) == 1)
    assert ord_17_mod_256 == 16

    beta_cube_test = fpow(BETA, (Q0 - 1) // 3)
    expected_cube_test = (2,) + (0,) * 7 + (5,) + (0,) * 7
    assert beta_cube_test == expected_cube_test != fone()

    U: L = (fzero(), fone(), fzero())
    assert lpow(U, 3) == lembed(BETA)

    def is_prime(n: int) -> bool:
        if n < 2:
            return False
        d = 2
        while d * d <= n:
            if n % d == 0:
                return n == d
            d += 1 if d == 2 else 2
        return True

    assert all(is_prime(p) for p in M_FACTORS)
    assert len(set(M_FACTORS)) == len(M_FACTORS)
    assert math.prod(M_FACTORS) == M
    assert R * M == QUOTIENT_ORDER
    assert math.gcd(R, M) == 1

    # Exact quotient kernel identity: gcd(q-1, q^3-1)=q-1, so z^(q-1)=1
    # has exactly q-1 roots, namely the embedded F0^x.
    assert math.gcd(Q0 - 1, Q0**3 - 1) == Q0 - 1

    # Packet count from exact 16-color convolution.
    one = [0] * 16
    for option in range(48):
        one[color(option)] += 1
    dist = [1] + [0] * 15
    for _ in range(7):
        dist = circular_convolution(dist, one)
    packet_count = dist[4]
    assert packet_count == 52_747_567_104

    # Support circuit: every slot contributes 16 distinct points in residue
    # class t mod 8, so the 7 slots plus {1} give 113; no nontrivial mu_32
    # point is ever used.
    for E in ESETS:
        assert len(E) == 8 and len(set(E)) == 8
    all_exp_sets: list[set[int]] = []
    for t in range(1, 8):
        for i in range(3):
            for a in range(16):
                exps: set[int] = set()
                for e0 in ESETS[i]:
                    b = (a + e0) & 15
                    e = (t + 8 * b) & 255
                    exps.add(e)
                    exps.add((e + 128) & 255)
                assert len(exps) == 16
                assert all(e % 8 == t for e in exps)
                all_exp_sets.append(exps)
    # Across different t, residue classes are disjoint.  The point 1 has exp 0.
    assert 1 + 7 * 16 == 113

    ep = [fone()]
    for _ in range(1, 256):
        ep.append(fmul(ep[-1], eta))
    assert ep[-1] != fone() and fmul(ep[-1], eta) == fone()

    header = b"RS-MCA-CYCLE86-U-SLOT-FACTORS-v1\0"
    stream = bytearray(header)
    factors: list[L] = []
    for t in range(1, 8):
        for i in range(3):
            for a in range(16):
                g = lone()
                for e0 in ESETS[i]:
                    b = (a + e0) & 15
                    power = (2 * t + 16 * b) & 255
                    term: L = (fneg(ep[power]), fzero(), fone())
                    g = lmul(g, term)
                assert g != lzero()
                factors.append(g)
                stream += bytes((t, i + 1, a))
                stream += encode_l(g)
    assert len(factors) == 336
    slot_sha = hashlib.sha256(stream).hexdigest()
    assert slot_sha == EXPECTED_SLOT_SHA
    slot_path = ROOT / "cycle87_u_slot_factors.bin"
    slot_path.write_bytes(stream)

    pnum = 52_747_567_104
    nocc = 52_747_567_092
    lower8 = pnum * nocc // 8
    assert lower8 == 347_788_229_344_751_517_696
    assert T_LINE == 338_617_018_271_848_945_628
    assert lower8 - T_LINE == 9_171_211_072_902_572_068

    result = {
        "schema": "cycle87.u-separator-setup.v1",
        "decision": "SETUP_VERIFIED",
        "field": {
            "p": 17,
            "base_degree": 16,
            "base_order": str(Q0),
            "modulus_coeffs_ascending": f,
            "rabin_x_q8_mod_f": x_q8,
            "rabin_x_q16_mod_f": x_q16,
            "rabin_gcd_q8": gcd8,
            "eta_coeffs": list(eta),
            "eta_order": 256,
            "ord_256_of_17": ord_17_mod_256,
            "beta_coeffs": list(BETA),
            "beta_cubic_character": list(beta_cube_test),
            "extension": "F0[U]/(U^3-beta)",
            "extension_degree_over_F17": 48,
        },
        "projective_quotient": {
            "order": str(QUOTIENT_ORDER),
            "smooth_order_M": str(M),
            "cofactor_R": str(R),
            "M_factorization": list(M_FACTORS),
            "gcd_R_M": math.gcd(R, M),
            "exact_key": "z^(q0-1)",
            "coarse_key": "z^((q0-1)R)",
        },
        "packet": {
            "support_size": 113,
            "packet_count": packet_count,
            "color_target_mod16": 4,
            "E_sets": [list(x) for x in ESETS],
            "s_colors": list(SCOLOR),
            "universal_deleted_exponents": [8 * b for b in range(1, 25)],
        },
        "slot_factor_table": {
            "records": 336,
            "path": slot_path.name,
            "bytes": len(stream),
            "sha256": slot_sha,
        },
        "official_arithmetic": {
            "q_line": str(Q_LINE),
            "T_line": str(T_LINE),
            "P": str(pnum),
            "N": str(nocc),
            "floor_PN_over_8": str(lower8),
            "margin": str(lower8 - T_LINE),
        },
    }
    out = ROOT / "cycle87_setup_certificate.json"
    out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
