#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <mutex>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>
#include <boost/multiprecision/cpp_int.hpp>

using boost::multiprecision::cpp_int;
using u8 = uint8_t;
using u16 = uint16_t;
using u32 = uint32_t;
using u64 = uint64_t;
using u128 = unsigned __int128;

static u128 parse_u128(const char* s){ u128 x=0; for(;*s;s++){ if(*s<'0'||*s>'9') continue; x=x*10+(*s-'0'); } return x; }
static std::string dec128(u128 x){ if(!x)return "0"; std::string s; while(x){ s.push_back(char('0'+x%10)); x/=10; } std::reverse(s.begin(),s.end()); return s; }
static cpp_int cpp_from_u128(u128 x){ cpp_int z=(u64)(x>>64); z <<= 64; z += (u64)x; return z; }

static constexpr int P=17, D=16;
struct F {
    std::array<u8,D> a{};
    bool operator==(const F& o) const noexcept { return a==o.a; }
    bool operator!=(const F& o) const noexcept { return !(*this==o); }
};
static F fzero(){ return F{}; }
static F fone(){ F x; x.a[0]=1; return x; }
static F fscalar(int c){ F x; c%=P; if(c<0)c+=P; x.a[0]=(u8)c; return x; }
static F fadd(const F&x,const F&y){ F z; for(int i=0;i<D;i++){int v=x.a[i]+y.a[i]; if(v>=P)v-=P; z.a[i]=v;} return z; }
static F fneg(const F&x){ F z; for(int i=0;i<D;i++) z.a[i]=x.a[i]?P-x.a[i]:0; return z; }
static F fsub(const F&x,const F&y){ return fadd(x,fneg(y)); }
static F fmul(const F&x,const F&y){
    int w[31]{};
    for(int i=0;i<D;i++) if(x.a[i]) for(int j=0;j<D;j++) if(y.a[j]) w[i+j] += int(x.a[i])*int(y.a[j]);
    for(int k=30;k>=16;k--){ int c=w[k]%P; if(c<0)c+=P; if(c){ w[k-8]-=c; w[k-16]-=3*c; } }
    F z; for(int i=0;i<D;i++){ int v=w[i]%P; if(v<0)v+=P; z.a[i]=(u8)v; } return z;
}
static F fpow(F b, cpp_int e){ F r=fone(); while(e>0){ if((e&1)!=0)r=fmul(r,b); b=fmul(b,b); e>>=1; } return r; }

static F BETA;
struct L {
    std::array<F,3> c{};
    bool operator==(const L&o)const noexcept{return c==o.c;}
    bool operator!=(const L&o)const noexcept{return !(*this==o);}
};
static L lzero(){return L{};}
static L lone(){L z;z.c[0]=fone();return z;}
static L lembed(const F&x){L z;z.c[0]=x;return z;}
static L ladd(const L&x,const L&y){L z;for(int i=0;i<3;i++)z.c[i]=fadd(x.c[i],y.c[i]);return z;}
static L lneg(const L&x){L z;for(int i=0;i<3;i++)z.c[i]=fneg(x.c[i]);return z;}
static L lsub(const L&x,const L&y){return ladd(x,lneg(y));}
static L lmul(const L&a,const L&b){
    L z;
    // c0=a0b0 + beta(a1b2+a2b1)
    z.c[0]=fadd(fmul(a.c[0],b.c[0]), fmul(BETA, fadd(fmul(a.c[1],b.c[2]), fmul(a.c[2],b.c[1]))));
    // c1=a0b1+a1b0+beta a2b2
    z.c[1]=fadd(fadd(fmul(a.c[0],b.c[1]), fmul(a.c[1],b.c[0])), fmul(BETA,fmul(a.c[2],b.c[2])));
    // c2=a0b2+a1b1+a2b0
    z.c[2]=fadd(fadd(fmul(a.c[0],b.c[2]), fmul(a.c[1],b.c[1])), fmul(a.c[2],b.c[0]));
    return z;
}
static L lpow(L b, cpp_int e){L r=lone();while(e>0){if((e&1)!=0)r=lmul(r,b);b=lmul(b,b);e>>=1;}return r;}
static L lpow128(L b,u128 e){L r=lone();while(e){if(e&1)r=lmul(r,b);b=lmul(b,b);e>>=1;}return r;}
static bool liszero(const L&x){return x==lzero();}

struct LHash {
    size_t operator()(const L&x) const noexcept {
        u64 h=0x9e3779b97f4a7c15ULL;
        for(int k=0;k<3;k++)for(int i=0;i<16;i++){
            h ^= u64(x.c[k].a[i])+0x9e3779b97f4a7c15ULL+(h<<6)+(h>>2);
            h ^= h>>30; h*=0xbf58476d1ce4e5b9ULL; h^=h>>27; h*=0x94d049bb133111ebULL; h^=h>>31;
        }
        return (size_t)h;
    }
};
static std::string lhex(const L&x){ static const char* d="0123456789abcdef"; std::string s; s.reserve(96); for(int k=0;k<3;k++)for(int i=0;i<16;i++){u8 v=x.c[k].a[i];s.push_back(d[v>>4]);s.push_back(d[v&15]);} return s; }

static const int ESET[3][8]={
 {0,1,2,3,5,11,12,13},
 {0,1,2,3,4,8,9,14},
 {0,1,2,4,5,7,11,14}
};
static const int SCOLOR[3]={15,9,12};
static inline int color(int k){int i=k/16,a=k%16;return (SCOLOR[i]+8*(a&1))&15;}

static const u128 MODM=parse_u128("48661191882642625923");
static const u128 COFR=parse_u128("48661191868691111041");
static const u128 Q0=parse_u128("48661191875666868481");
static const u64 PRIMEF[8]={3,7,13,73,307,1321,72337,83233};
static inline u128 addm(u128 a,u128 b){u128 s=a+b;if(s>=MODM)s-=MODM;return s;}
static inline u128 mulmod(u128 a,u128 b,u128 m){ // safe here: a,b<2^66, product<2^132 may exceed u128
    // double-and-add; only setup CRT, not hot loop
    u128 r=0;
    while(b){if(b&1){r+=a;if(r>=m)r-=m;}b>>=1;if(b){a+=a;if(a>=m)a-=m;}}
    return r;
}
static u64 invmod_u64(u64 a,u64 p){ // p prime/small; extended Euclid
    int64_t t=0,nt=1; int64_t r=(int64_t)p,nr=(int64_t)(a%p);
    while(nr){int64_t q=r/nr;int64_t z=t-q*nt;t=nt;nt=z;z=r-q*nr;r=nr;nr=z;}
    if(r!=1)throw std::runtime_error("noninvertible CRT");if(t<0)t+=p;return (u64)t;
}
static u128 crt8(const std::array<u32,8>& a){
    u128 x=0;
    for(int i=0;i<8;i++){
        u128 Mi=MODM/PRIMEF[i];
        u64 rem=(u64)(Mi%PRIMEF[i]);
        u64 inv=invmod_u64(rem,PRIMEF[i]);
        u128 term=mulmod(Mi,(u128)a[i]*inv%PRIMEF[i],MODM);
        x+=term; if(x>=MODM)x-=MODM;
    }
    return x;
}

static u128 W[7][48];
static L GRAW[7][48], GPROJ[7][48];
static L HGEN;

static void setup_slots(){
    BETA=fzero();BETA.a[0]=2;BETA.a[1]=1;
    F eta=fzero();eta.a[9]=6;
    if(fpow(eta,cpp_int(256))!=fone())throw std::runtime_error("eta^256");
    if(fpow(eta,cpp_int(128))!=fscalar(-1))throw std::runtime_error("eta^128");
    F beta_cubetest=fpow(BETA,(cpp_from_u128(Q0)-1)/3);
    F expected=fzero();expected.a[0]=2;expected.a[8]=5;
    if(beta_cubetest!=expected)throw std::runtime_error("beta cubic test mismatch");
    if(beta_cubetest==fone())throw std::runtime_error("beta cube");
    L U=lzero();U.c[1]=fone();
    if(lpow(U,cpp_int(3))!=lembed(BETA))throw std::runtime_error("U relation");
    std::array<F,256> ep;ep[0]=fone();for(int i=1;i<256;i++)ep[i]=fmul(ep[i-1],eta);
    for(int t=1;t<=7;t++)for(int k=0;k<48;k++){
        int ii=k/16,a=k%16; L g=lone();
        for(int z=0;z<8;z++){
            int b=(a+ESET[ii][z])&15; int e=(2*t+16*b)&255;
            L term=lzero();term.c[0]=fneg(ep[e]);term.c[2]=fone();
            g=lmul(g,term);
        }
        if(liszero(g))throw std::runtime_error("zero slot factor");
        GRAW[t-1][k]=g;
    }
    cpp_int ex=(cpp_from_u128(Q0)-1)*cpp_from_u128(COFR);
    for(int t=0;t<7;t++)for(int k=0;k<48;k++) GPROJ[t][k]=lpow(GRAW[t][k],ex);

    // deterministic short candidate sequence for a smooth-subgroup generator.
    std::vector<L> cand;
    cand.push_back(U);
    cand.push_back(ladd(U,lone()));
    F X=fzero();X.a[1]=1;
    cand.push_back(ladd(U,lembed(X)));
    L U2=lmul(U,U);cand.push_back(ladd(U2,lone()));cand.push_back(ladd(U2,U));cand.push_back(ladd(ladd(U2,U),lone()));
    for(int c=2;c<64;c++)cand.push_back(ladd(U,lembed(fscalar(c%17))));
    bool found=false;size_t ci=0;
    for(;ci<cand.size();ci++){
        L h=lpow(cand[ci],ex);
        if(h==lone())continue;
        if(lpow128(h,MODM)!=lone())throw std::runtime_error("projection order does not divide M");
        bool exact=true;for(u64 p:PRIMEF)if(lpow128(h,MODM/p)==lone()){exact=false;break;}
        if(exact){HGEN=h;found=true;break;}
    }
    if(!found)throw std::runtime_error("no generator in candidate sequence");
    std::cerr<<"smooth generator candidate_index="<<ci<<" hex="<<lhex(HGEN)<<"\n";

    std::array<std::array<u32,8>,336> residues{};
    for(int fi=0;fi<8;fi++){
        u64 p=PRIMEF[fi]; L gp=lpow128(HGEN,MODM/p);
        std::unordered_map<L,u32,LHash> tab;tab.reserve((size_t)(p*1.35)+16);tab.max_load_factor(0.8f);
        L cur=lone();for(u32 j=0;j<p;j++){auto ok=tab.emplace(cur,j);if(!ok.second)throw std::runtime_error("DLP table early repeat");cur=lmul(cur,gp);}if(cur!=lone())throw std::runtime_error("DLP table no closure");
        for(int t=0;t<7;t++)for(int k=0;k<48;k++){
            L xp=lpow128(GPROJ[t][k],MODM/p);auto it=tab.find(xp);if(it==tab.end())throw std::runtime_error("DLP not found");residues[t*48+k][fi]=it->second;
        }
        std::cerr<<"dlog factor p="<<p<<" complete\n";
    }
    for(int t=0;t<7;t++)for(int k=0;k<48;k++){
        W[t][k]=crt8(residues[t*48+k]);
        if(lpow128(HGEN,W[t][k])!=GPROJ[t][k])throw std::runtime_error("CRT log verify");
    }
    std::cerr<<"all 336 projected logs verified\n";
}

struct ARec{u128 x;u32 idx;u8 c;};
struct BRec{u128 x;u32 idx;};
static std::vector<ARec>A;
static std::array<std::vector<BRec>,16>B;
static inline u64 mix64(u64 x){x^=x>>30;x*=0xbf58476d1ce4e5b9ULL;x^=x>>27;x*=0x94d049bb133111ebULL;x^=x>>31;return x;}
static inline size_t lb(const std::vector<BRec>&v,u128 x){return std::lower_bound(v.begin(),v.end(),x,[](const BRec&a,u128 y){return a.x<y;})-v.begin();}
static inline u64 range_count(const std::vector<BRec>&v,u128 lo,u128 hi){if(lo<hi)return lb(v,hi)-lb(v,lo);if(lo>hi)return(v.size()-lb(v,lo))+lb(v,hi);throw std::runtime_error("zero-width range");}
static constexpr u64 KEYMASK=(1ULL<<56)-1;
struct Result{u64 pairs=0,unique=0,D=0;u8 maxc=0;bool coarse_hit=false;u128 hitv=0;double sec=0;};

static Result process_shard(u32 sh,u32 NS){
    auto st=std::chrono::steady_clock::now();u128 Lb=(MODM*sh)/NS,Ub=(MODM*(sh+1))/NS;
    if(Ub-Lb>KEYMASK-1)throw std::runtime_error("shard width exceeds 56-bit key");
    u64 np=0;
    for(const auto&a:A){const auto&v=B[(4-a.c)&15];u128 lo=Lb>=a.x?Lb-a.x:Lb+MODM-a.x,hi=Ub>=a.x?Ub-a.x:Ub+MODM-a.x;np+=range_count(v,lo,hi);}
    size_t cap=1;while(cap<(size_t)(np/0.55)+1)cap<<=1;
    std::vector<u64> table(cap,0);size_t mask=cap-1;Result out;out.pairs=np;
    auto insert=[&](u128 sum){
        u64 off=(u64)(sum-Lb),kp=off+1;size_t h=mix64(off)&mask;
        while(true){u64 e=table[h];if(!e){table[h]=(1ULL<<56)|kp;out.unique++;if(out.maxc<1)out.maxc=1;return;}
            if((e&KEYMASK)==kp){unsigned old=e>>56,now=old+1;out.D+=2ull*old;table[h]=((u64)now<<56)|kp;if(now>out.maxc)out.maxc=now;if(now>=9&&!out.coarse_hit){out.coarse_hit=true;out.hitv=sum;}return;}h=(h+1)&mask;}
    };
    for(const auto&a:A){const auto&v=B[(4-a.c)&15];u128 lo=Lb>=a.x?Lb-a.x:Lb+MODM-a.x,hi=Ub>=a.x?Ub-a.x:Ub+MODM-a.x;
        auto run=[&](size_t p,size_t q){for(size_t j=p;j<q;j++)insert(addm(a.x,v[j].x));};
        if(lo<hi)run(lb(v,lo),lb(v,hi));else{run(lb(v,lo),v.size());run(0,lb(v,hi));}
    }
    out.sec=std::chrono::duration<double>(std::chrono::steady_clock::now()-st).count();return out;
}

static void build_mitm(){
    A.reserve(48*48*48);
    for(int k1=0;k1<48;k1++)for(int k2=0;k2<48;k2++)for(int k3=0;k3<48;k3++){
        u128 x=addm(addm(W[0][k1],W[1][k2]),W[2][k3]);u8 c=(color(k1)+color(k2)+color(k3))&15;u32 id=(k1*48+k2)*48+k3;A.push_back({x,id,c});
    }
    for(int k4=0;k4<48;k4++)for(int k5=0;k5<48;k5++)for(int k6=0;k6<48;k6++)for(int k7=0;k7<48;k7++){
        u128 x=addm(addm(W[3][k4],W[4][k5]),addm(W[5][k6],W[6][k7]));u8 c=(color(k4)+color(k5)+color(k6)+color(k7))&15;u32 id=((k4*48+k5)*48+k6)*48+k7;B[c].push_back({x,id});
    }
    for(auto&v:B)std::sort(v.begin(),v.end(),[](const BRec&a,const BRec&b){return a.x<b.x||(a.x==b.x&&a.idx<b.idx);});
    u64 compat=0;std::array<u64,16> ac{},bc{};for(auto&a:A)ac[a.c]++;for(int c=0;c<16;c++)bc[c]=B[c].size();for(int c=0;c<16;c++)compat+=ac[c]*bc[(4-c)&15];
    std::cerr<<"left="<<A.size()<<" right=5308416 compatible="<<compat<<"\n";
    if(compat!=52747567104ULL)throw std::runtime_error("compatible count mismatch");
}

int main(int argc,char**argv){
    try{
        u32 NS=1536,threads=4;if(argc>1)NS=std::stoul(argv[1]);if(argc>2)threads=std::stoul(argv[2]);std::string outpath=argc>3?argv[3]:"cycle87_u_smooth_census.json";
        auto allst=std::chrono::steady_clock::now();setup_slots();build_mitm();
        std::vector<Result>R(NS);std::atomic<u32>next{0};std::mutex pm;
        auto worker=[&](u32 tid){while(true){u32 sh=next.fetch_add(1);if(sh>=NS)break;R[sh]=process_shard(sh,NS);if((sh%64)==0){std::lock_guard<std::mutex>g(pm);std::cerr<<"progress assigned="<<std::min(next.load(),NS)<<"/"<<NS<<" last="<<sh<<" sec="<<R[sh].sec<<" max="<<(unsigned)R[sh].maxc<<" D="<<R[sh].D<<"\n";}}};
        std::vector<std::thread>th;for(u32 i=0;i<threads;i++)th.emplace_back(worker,i);for(auto&t:th)t.join();
        u64 pairs=0,unique=0,Dtot=0;u8 mmax=0;bool hit=false;u128 hitv=0;for(auto&r:R){pairs+=r.pairs;unique+=r.unique;Dtot+=r.D;if(r.maxc>mmax)mmax=r.maxc;if(r.coarse_hit&&!hit){hit=true;hitv=r.hitv;}}
        double elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-allst).count();
        std::ofstream o(outpath);o<<"{\n";
        o<<"  \"schema\": \"cycle87.u-smooth-projective-census.v1\",\n";
        o<<"  \"decision\": \""<<(hit?"COARSE_MMAX_GE_9_REFINEMENT_REQUIRED":"PROJECTIVE_MMAX_CERTIFIED_LE_8")<<"\",\n";
        o<<"  \"q0\": \""<<dec128(Q0)<<"\",\n  \"quotient_order\": \"2367911594760467245892767489196618115843\",\n";
        o<<"  \"smooth_order_M\": \""<<dec128(MODM)<<"\",\n  \"cofactor_R\": \""<<dec128(COFR)<<"\",\n";
        o<<"  \"smooth_generator_hex\": \""<<lhex(HGEN)<<"\",\n";
        o<<"  \"records\": "<<pairs<<",\n  \"projected_occupancy\": "<<unique<<",\n  \"D_projected_offdiagonal_ordered\": "<<Dtot<<",\n  \"projected_max_multiplicity\": "<<(unsigned)mmax<<",\n";
        o<<"  \"coarse_hit_log\": "<<(hit?("\""+dec128(hitv)+"\""):"null")<<",\n";
        o<<"  \"shards\": {\"count\": "<<NS<<", \"threads\": "<<threads<<"},\n  \"elapsed_seconds\": "<<std::setprecision(15)<<elapsed<<"\n}\n";
        o.close();
        std::cout<<"pairs="<<pairs<<" unique="<<unique<<" D="<<Dtot<<" projected_mmax="<<(unsigned)mmax<<" hit="<<hit<<" elapsed="<<elapsed<<" cert="<<outpath<<"\n";
        return hit?9:0;
    }catch(const std::exception&e){std::cerr<<"ERROR: "<<e.what()<<"\n";return 2;}
}
