# Cycle87 `U`-Separator Replay Bundle

The bundle proves the concrete separator bound `mu_proj(U)<=2` and materializes the preferred `(464,232,6,226)` two-copy GRS package.

## Fast verification of the shipped certificate

```bash
python3 cycle87_verify_master.py
```

This verifies all shipped artifact hashes, all certificate arithmetic, the smooth histogram, the GRS artifact certificate, and the final threshold comparison.

## Full census replay

Requirements: Python 3, a C++17 compiler, Boost headers, about 2.3 GiB RAM with four threads, and sufficient temporary memory for the in-memory shard tables.

```bash
THREADS=4 SHARDS=1536 ./REPLAY_CYCLE87_U_SEPARATOR.sh
```

The recorded execution used 1,536 shards and four threads. It took 940.49 seconds in the checker, 15:40.50 under `/usr/bin/time`, with maximum RSS 2,299,780 KiB.

The census is deterministic. Hashing is used only for table placement; the stored 55-bit shard offsets are compared exactly. A successful replay must report:

```text
records                         52747567104
projected_occupancy             52747567062
D_projected_offdiagonal_ordered 84
projected_max_multiplicity      2
coarse_hit_log                  null
```

## Main files

- `CYCLE87_U_SEPARATOR_PROOF.md`: theorem, construction, algorithms, scope, and self-audit.
- `cycle87_master_certificate.json`: master machine-readable certificate.
- `cycle87_setup_verifier.py`: exact field, irreducibility, support, factorization, and slot-factor verifier.
- `cycle87_u_smooth_census.cpp`: exact 52.7-billion-record smooth quotient census.
- `cycle87_464_materializer.cpp`: explicit domain, GRS parity-check matrix, and line generator.
- `cycle87_verify_464_artifacts.py`: exact binary artifact verifier.
- `cycle87_certificate_schema.json`: PASS, refinement-required, and exact counterpacket schema.
