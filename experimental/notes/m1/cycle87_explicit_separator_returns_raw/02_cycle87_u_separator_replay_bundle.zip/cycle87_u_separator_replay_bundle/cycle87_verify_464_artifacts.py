#!/usr/bin/env python3
"""Exact verifier for the materialized Cycle87 [464,232] GRS/domain/line files."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import cycle87_setup_verifier as s  # exact field arithmetic

DOMAIN = ROOT / "cycle87_domain464.bin"
MATRIX = ROOT / "cycle87_grs_H_232x464.bin"
LINE = ROOT / "cycle87_line_464.bin"


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            b = f.read(1 << 20)
            if not b:
                return h.hexdigest()
            h.update(b)


def read_u32(data: bytes, pos: int) -> tuple[int, int]:
    if pos + 4 > len(data):
        raise ValueError("truncated uint32")
    return int.from_bytes(data[pos:pos+4], "big"), pos + 4


def read_l(data: bytes, pos: int) -> tuple[s.L, int]:
    if pos + 48 > len(data):
        raise ValueError("truncated L element")
    c = []
    for _ in range(3):
        v = tuple(data[pos:pos+16])
        if any(x >= 17 for x in v):
            raise ValueError("noncanonical base-17 coefficient")
        c.append(v)
        pos += 16
    return (c[0], c[1], c[2]), pos


def parse_header(data: bytes, text: bytes) -> int:
    h = text + b"\0"
    if not data.startswith(h):
        raise ValueError(f"header mismatch: expected {text!r}")
    return len(h)


def poly_mul(a: list[s.L], b: list[s.L]) -> list[s.L]:
    out = [s.lzero() for _ in range(6)]
    for i in range(6):
        for j in range(6 - i):
            out[i+j] = s.ladd(out[i+j], s.lmul(a[i], b[j]))
    return out


def poly_pow(a: list[s.L], n: int) -> list[s.L]:
    r = [s.lzero() for _ in range(6)]
    r[0] = s.lone()
    while n:
        if n & 1:
            r = poly_mul(r, a)
        a = poly_mul(a, a)
        n >>= 1
    return r


def main() -> None:
    eta = (0,) * 9 + (6,) + (0,) * 6
    ep = [s.fone()]
    for _ in range(1, 256):
        ep.append(s.fmul(ep[-1], eta))
    U: s.L = (s.fzero(), s.fone(), s.fzero())
    c = s.lsub(s.lembed(s.BETA), U)

    exps = [e for e in range(256) if not (8 <= e <= 192 and e % 8 == 0)]
    assert len(exps) == 232
    expected_domain = [s.lembed(ep[e]) for e in exps]
    expected_domain += [s.ladd(c, s.lembed(ep[e])) for e in exps]

    ddata = DOMAIN.read_bytes()
    pos = parse_header(ddata, b"RS-MCA-CYCLE87-DOMAIN-464-v1")
    n, pos = read_u32(ddata, pos)
    assert n == 464
    domain: list[s.L] = []
    for _ in range(n):
        x, pos = read_l(ddata, pos)
        domain.append(x)
    assert pos == len(ddata)
    assert domain == expected_domain
    assert len(set(domain)) == 464
    assert s.lembed(s.BETA) not in set(domain)
    assert domain[exps.index(0)] == s.lone()
    assert domain[exps.index(1)] == s.lembed(eta)
    assert domain[232 + exps.index(0)] == s.ladd(c, s.lone())

    mdata = MATRIX.read_bytes()
    pos = parse_header(mdata, b"RS-MCA-CYCLE87-GRS-H-232x464-v1")
    rows, pos = read_u32(mdata, pos)
    cols, pos = read_u32(mdata, pos)
    assert (rows, cols) == (232, 464)
    for x in domain:
        pw = s.lone()
        for _m in range(231):
            got, pos = read_l(mdata, pos)
            assert got == pw
            pw = s.lmul(pw, x)
        inv, pos = read_l(mdata, pos)
        den = s.lsub(s.lembed(s.BETA), x)
        assert s.lmul(den, inv) == s.lone()
    assert pos == len(mdata)

    # Recompute A(t)=(1-t)(1-ct)^112(1-(c+1)t) and its inverse mod t^6.
    one = s.lone()
    p1 = [s.lzero() for _ in range(6)]
    p1[0], p1[1] = one, s.lneg(one)
    pc = [s.lzero() for _ in range(6)]
    pc[0], pc[1] = one, s.lneg(c)
    pc1 = [s.lzero() for _ in range(6)]
    pc1[0], pc1[1] = one, s.lneg(s.ladd(c, one))
    A = poly_mul(poly_mul(p1, poly_pow(pc, 112)), pc1)
    H = [s.lzero() for _ in range(6)]
    H[0] = one
    for n0 in range(1, 6):
        acc = s.lzero()
        for i in range(1, n0 + 1):
            acc = s.ladd(acc, s.lmul(A[i], H[n0-i]))
        H[n0] = s.lneg(acc)
    assert poly_mul(A, H)[0] == one
    assert all(x == s.lzero() for x in poly_mul(A, H)[1:])

    ldata = LINE.read_bytes()
    pos = parse_header(ldata, b"RS-MCA-CYCLE87-LINE-464-v1")
    dim, pos = read_u32(ldata, pos)
    assert dim == 232
    u: list[s.L] = []
    v: list[s.L] = []
    for _ in range(dim):
        x, pos = read_l(ldata, pos)
        u.append(x)
    for _ in range(dim):
        x, pos = read_l(ldata, pos)
        v.append(x)
    assert pos == len(ldata)
    expected_u = [s.lzero() for _ in range(232)]
    for r in range(6):
        expected_u[225+r] = H[r]
    expected_v = [s.lzero() for _ in range(232)]
    expected_v[231] = one
    assert u == expected_u
    assert v == expected_v

    # The explicit column family becomes, after scaling by beta-x, evaluations
    # of 1 and Y^m(beta-Y), 0<=m<=230.  These form a basis of L[Y]_{<=231}.
    # Transversality uses rows 0..230: 226 distinct support columns have full
    # Vandermonde rank because 226 <= 231.
    assert 226 <= 231 < 232

    result = {
        "schema": "cycle87.grs464-artifacts.v1",
        "decision": "GRS464_ARTIFACTS_VERIFIED",
        "profile": {"n": 464, "k": 232, "sigma": 6, "j": 226, "t": 1},
        "domain": {
            "count": 464,
            "deleted_exponents_per_block": [8*b for b in range(1, 25)],
            "distinct": True,
            "beta_excluded": True,
            "generates_L_reason": "contains 1, eta, and c+1; hence F0 and c=beta-U, then U",
            "sha256": sha(DOMAIN),
            "bytes": DOMAIN.stat().st_size,
        },
        "parity_check": {
            "rows": 232,
            "columns": 464,
            "column_formula": "(1,x,...,x^230,(beta-x)^-1)",
            "all_entries_verified": True,
            "grs_equivalence_basis": "1 and Y^m(beta-Y), 0<=m<=230",
            "sha256": sha(MATRIX),
            "bytes": MATRIX.stat().st_size,
        },
        "line": {
            "dimension": 232,
            "base_rows_0_224_zero": True,
            "base_rows_225_230": "coefficients of ((1-t)(1-ct)^112(1-(c+1)t))^-1 mod t^6",
            "direction": "last standard basis vector",
            "sha256": sha(LINE),
            "bytes": LINE.stat().st_size,
        },
        "transversality": {
            "support_size": 226,
            "vandermonde_rows": 231,
            "certified": True,
        },
    }
    out = ROOT / "cycle87_464_artifact_certificate.json"
    out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
