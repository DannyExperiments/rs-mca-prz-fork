# Cycle 48 Upper Inverse Context Packet

Purpose: final nightly push after Cycle 47.

Cycle 47 appears to close the smooth-domain MCA lower/failure branch via the
domain-uniform Bessel moment theorem. The remaining full-MCA wall is the
opposite-quantifier upper/inverse theorem above entropy.

Primary target:

```text
W-MCA-AA-RES-ENTROPY-BOUNDARY-MATCHING-UPPER
```

Equivalent labels:

```text
W-M1-AA-BALANCED-RESIDUE-CLOUD-UNIFORM-UPPER
W-M1-AA-RES-ABOVE-ENTROPY-QUOTIENT-SEPARATED-UNIFORM-UPPER-PACKING
```

Use fresh model instances. Upload this zip and paste exactly one file from
`prompts/01_...` through `prompts/09_...` into each instance.

Read order:

1. `repo_current/20260619_CYCLE47_DOMAIN_UNIFORM_BESSEL_AUDIT.md`
2. `repo_current/slackMCA_v3.tex`
3. `repo_current/proximity_blueprint_v3.tex`
4. `origin_main/experimental/paper_b_counterexample_comparison.md`
5. `origin_main/experimental/f1_extension_coordinate_transfer.md`
6. `origin_main/experimental/l2_interleaved_support_bridge.md`
7. `origin_main/experimental/2026-06-17-codex-f1-l1-audit/audits/20260617_OPUS48_F1_RESIDUAL_SLACK_AUDIT.md`
8. `origin_main/experimental/2026-06-17-codex-f1-l1-audit/audits/20260617_OPUS48_F1_BASE_CORE_REDUCTION_AUDIT.md`
9. `origin_main/experimental/2026-06-17-codex-f1-l1-audit/audits/20260617_OPUS48_F1_BALANCED_CRT_AUDIT.md`

Classification discipline:

- Use only `PROOF`, `PROOF_CANDIDATE`, `BANKABLE_LEMMA`, `ROUTE_CUT`,
  `EXACT_NEW_WALL`, `COUNTERPACKET`, `AUDIT`, or `EXPERIMENTAL`.
- Keep lower/failure branch separate from upper/safe branch.
- Keep scalar MCA separate from list decoding.
- Keep `q_gen`, `q_line`, `q_chal`, `B`, `F`, `D/L`, `n`, `k`, `t`, `sigma`,
  `a`, and `j` separate.
